%{
#include <stdio.h>
#include <stdlib.h>

void yyerror(const char *s);
int yylex(void);

extern FILE *yyin;
%}

/* ======================
       ERRORES VERBOSE
   ====================== */
%define parse.error verbose
%locations

/* ======================
       DATOS DEL YACC
   ====================== */
%union {
    char* id;
    int entero;
    float real;
    char caracter;
    char* cadena;
}

/* ======================
          TOKENS
   ====================== */
%token TOKEN_AUTO TOKEN_DEFINE TOKEN_INCLUDE
%token TOKEN_BREAK TOKEN_CASE TOKEN_CHAR TOKEN_CONST TOKEN_CONTINUE
%token TOKEN_DEFAULT TOKEN_DO TOKEN_DOUBLE TOKEN_ELSE TOKEN_ENUM
%token TOKEN_EXTERN TOKEN_FLOAT TOKEN_FOR TOKEN_GOTO TOKEN_IF
%token TOKEN_INT TOKEN_LONG TOKEN_REGISTER TOKEN_RETURN TOKEN_SHORT
%token TOKEN_SIGNED TOKEN_SIZEOF TOKEN_STATIC TOKEN_STRUCT TOKEN_SWITCH
%token TOKEN_TYPEDEF TOKEN_UNION TOKEN_UNSIGNED TOKEN_VOID TOKEN_VOLATILE
%token TOKEN_WHILE

%token <id> TOKEN_ID
%token <entero> TOKEN_CONST_ENTERO
%token <real> TOKEN_CONST_FLOTANTE
%token <caracter> TOKEN_CONST_CARACTER
%token <cadena> TOKEN_CONST_CADENA

%token TOKEN_ADD_ASSIGN TOKEN_SUB_ASSIGN TOKEN_MUL_ASSIGN TOKEN_DIV_ASSIGN TOKEN_MOD_ASSIGN
%token TOKEN_SHL_ASSIGN TOKEN_SHR_ASSIGN TOKEN_AND_ASSIGN TOKEN_XOR_ASSIGN TOKEN_OR_ASSIGN

%token TOKEN_INC TOKEN_DEC TOKEN_TERN_IF
%token TOKEN_MAS TOKEN_MOD TOKEN_MENOS TOKEN_MULT TOKEN_DIV TOKEN_ASIGN
%token TOKEN_IGUAL TOKEN_DIF TOKEN_MENOR TOKEN_MAYOR TOKEN_MENOR_IGUAL TOKEN_MAYOR_IGUAL
%token TOKEN_AND TOKEN_OR TOKEN_NOT
%token TOKEN_AND_BIT TOKEN_OR_BIT TOKEN_XOR TOKEN_DESPL_IZQ TOKEN_DESPL_DER

%token TOKEN_PUNTO_COMA TOKEN_DOS_PUNTO TOKEN_GATO TOKEN_COMA TOKEN_TILDE
%token TOKEN_PARENT_IZQ TOKEN_PARENT_DER
%token TOKEN_LLAVE_IZQ TOKEN_LLAVE_DER
%token TOKEN_CORCH_IZQ TOKEN_CORCH_DER
%token TOKEN_PUNTO TOKEN_FLECHA
%token TOKEN_ERROR

/* ======================
          PRECEDENCIAS
   ====================== */

/* Para resolver dangling else */
%nonassoc LOWER_THAN_ELSE
%nonassoc TOKEN_ELSE

/* Precedencias aritméticas y lógicas */
%right TOKEN_ASIGN

%left TOKEN_OR
%left TOKEN_AND

%left TOKEN_IGUAL TOKEN_DIF

%left TOKEN_MENOR TOKEN_MAYOR TOKEN_MENOR_IGUAL TOKEN_MAYOR_IGUAL

%left TOKEN_MAS TOKEN_MENOS
%left TOKEN_MULT TOKEN_DIV TOKEN_MOD

%right TOKEN_NOT

/* ======================
          INICIO
   ====================== */
%start programa

%%

/* ======================
        GRAMÁTICA
   ====================== */

/* Programa = una o varias funciones */
programa:
      funciones
;

funciones:
      funcion
    | funciones funcion
;

/* función sin parámetros */
funcion:
      tipo TOKEN_ID TOKEN_PARENT_IZQ TOKEN_PARENT_DER bloque
;

/* Tipos básicos */
tipo:
      TOKEN_INT
    | TOKEN_FLOAT
    | TOKEN_CHAR
    | TOKEN_VOID
;

/* Bloque de sentencias y/o declaraciones */
bloque:
      TOKEN_LLAVE_IZQ contenido TOKEN_LLAVE_DER
;

contenido:
      /* vacío */
    | contenido declaracion
    | contenido sentencia
;

/* Declaración tipo: int x;, float a = 10; */
declaracion:
      tipo declarador_list TOKEN_PUNTO_COMA
;

/* Lista declaradores: int a, b=2; */
declarador_list:
      declarador
    | declarador_list TOKEN_COMA declarador
;

/* Declarador individual */
declarador:
      TOKEN_ID
    | TOKEN_ID TOKEN_ASIGN expresion
;

/* Declaración sin ; (solo para for) */
declaracion_sin_punto_coma:
      tipo declarador_list
;

/* ======================
        SENTENCIAS
   ====================== */

sentencia:
      sentencia_expresion
    | sentencia_return
    | sentencia_if
    | sentencia_for
    | sentencia_while
    | bloque
;

sentencia_expresion:
      expresion TOKEN_PUNTO_COMA
;

/* return ; o return expr ; */
sentencia_return:
      TOKEN_RETURN TOKEN_PUNTO_COMA
    | TOKEN_RETURN expresion TOKEN_PUNTO_COMA
;

/* if (...) sentencia | if (...) sentencia else sentencia */
sentencia_if:
      TOKEN_IF TOKEN_PARENT_IZQ expresion TOKEN_PARENT_DER sentencia %prec LOWER_THAN_ELSE
    | TOKEN_IF TOKEN_PARENT_IZQ expresion TOKEN_PARENT_DER sentencia TOKEN_ELSE sentencia
;

/* while (...) sentencia */
sentencia_while:
      TOKEN_WHILE TOKEN_PARENT_IZQ expresion TOKEN_PARENT_DER sentencia
;

/* FOR completo: for(init; cond; inc) sentencia */
sentencia_for:
      TOKEN_FOR TOKEN_PARENT_IZQ for_init TOKEN_PUNTO_COMA for_cond TOKEN_PUNTO_COMA for_inc TOKEN_PARENT_DER sentencia
;

for_init:
      /* vacío */
    | asignacion
    | declaracion_sin_punto_coma
;

for_cond:
      /* vacío */
    | expresion
;

for_inc:
      /* vacío */
    | asignacion
    | expresion
;

/* ======================
        EXPRESIONES
   ====================== */

asignacion:
      TOKEN_ID TOKEN_ASIGN expresion
;

expresion:
      literal
    | TOKEN_ID
    | asignacion
    | TOKEN_PARENT_IZQ expresion TOKEN_PARENT_DER
    | expresion TOKEN_MAS expresion
    | expresion TOKEN_MENOS expresion
    | expresion TOKEN_MULT expresion
    | expresion TOKEN_DIV expresion
    | expresion TOKEN_MOD expresion
    | expresion TOKEN_MENOR expresion
    | expresion TOKEN_MAYOR expresion
    | expresion TOKEN_MENOR_IGUAL expresion
    | expresion TOKEN_MAYOR_IGUAL expresion
    | expresion TOKEN_IGUAL expresion
    | expresion TOKEN_DIF expresion
    | expresion TOKEN_AND expresion
    | expresion TOKEN_OR expresion
    | expresion TOKEN_INC      /* x++ */
    | expresion TOKEN_DEC      /* x-- */
    | TOKEN_INC expresion      /* ++x */
    | TOKEN_DEC expresion      /* --x */
;

/* Literales básicos */
literal:
      TOKEN_CONST_ENTERO
    | TOKEN_CONST_FLOTANTE
    | TOKEN_CONST_CARACTER
    | TOKEN_CONST_CADENA
;

%%

/* ======================
       MANEJO DE ERRORES
   ====================== */
void yyerror(const char *s){
    fprintf(stderr, "[ERROR] %s en la línea %d, columna %d\n",
           s, yylloc.first_line, yylloc.first_column);
}

/* ======================
   PROGRAMA PRINCIPAL
   ====================== */
int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Uso: %s <archivo.c>\n", argv[0]);
        return 1;
    }

    FILE* file = fopen(argv[1], "r");
    if (!file) {
        printf("❌ Error: no se puede abrir el archivo '%s'\n", argv[1]);
        return 1;
    }

    yyin = file;

    printf("Compilador COMPI Iniciado...\n");

    int result = yyparse();

    if (result == 0)
        printf("✔ Código válido\n");
    else
        printf("✖ Código inválido\n");

    fclose(file);
    return result;
}

