#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define MAX_LINE_LENGTH 1024
#define MAX_LINEAS 1000

// Configuración de estilos
typedef struct {
    int tamano_indentacion;
    int estilo_llaves;
    bool espacio_antes_parentesis;
    bool espacios_alrededor_operadores;
    bool lineas_vacias_entre_funciones;
    bool espacio_despues_comas;
    bool salto_linea_despues_punto_coma;
    int max_longitud_linea;
} ConfiguracionEstilo;

// CONFIGURACIÓN DE ESTILOS

void configurar_estilo_gnu(ConfiguracionEstilo* estilo) {
    estilo->tamano_indentacion = 2;
    estilo->estilo_llaves = 1; // Llaves en línea siguiente
    estilo->espacio_antes_parentesis = true;
    estilo->espacios_alrededor_operadores = true;
    estilo->lineas_vacias_entre_funciones = true;
    estilo->espacio_despues_comas = true;
    estilo->salto_linea_despues_punto_coma = true;
    estilo->max_longitud_linea = 80;
}

void configurar_estilo_bsd(ConfiguracionEstilo* estilo) {
    estilo->tamano_indentacion = 4;
    estilo->estilo_llaves = 1; // Llaves en línea siguiente
    estilo->espacio_antes_parentesis = false;
    estilo->espacios_alrededor_operadores = true;
    estilo->lineas_vacias_entre_funciones = true;
    estilo->espacio_despues_comas = true;
    estilo->salto_linea_despues_punto_coma = true;
    estilo->max_longitud_linea = 80;
}

void configurar_estilo_personalizado(ConfiguracionEstilo* estilo) {
    estilo->tamano_indentacion = 4;
    estilo->estilo_llaves = 0; // Llaves en misma línea
    estilo->espacio_antes_parentesis = true;
    estilo->espacios_alrededor_operadores = false;
    estilo->lineas_vacias_entre_funciones = false;
    estilo->espacio_despues_comas = false;
    estilo->salto_linea_despues_punto_coma = true;
    estilo->max_longitud_linea = 120;
}

// FUNCIONES AUXILIARES

void aplicar_indentacion(FILE* salida, int nivel, int tamano_indent) {
    for (int i = 0; i < nivel * tamano_indent; i++) {
        fputc(' ', salida);
    }
}

bool es_directiva_preprocesador(const char* linea) {
    const char* pos = linea;
    while (*pos && isspace(*pos)) pos++;
    return *pos == '#';
}

bool es_linea_comentario(const char* linea) {
    const char* pos = linea;
    while (*pos && isspace(*pos)) pos++;
    return (*pos == '/' && (*(pos + 1) == '/' || *(pos + 1) == '*'));
}

void contar_llaves(const char* linea, int* llaves_abiertas, int* llaves_cerradas) {
    *llaves_abiertas = 0;
    *llaves_cerradas = 0;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    
    for (const char* p = linea; *p; p++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (*p == '/' && *(p + 1) == '/') break;
            if (*p == '/' && *(p + 1) == '*') en_comentario = true;
            if (*p == '"' && (p == linea || *(p - 1) != '\\')) en_cadena = true;
            if (*p == '\'' && (p == linea || *(p - 1) != '\\')) en_caracter = true;
            if (*p == '{') (*llaves_abiertas)++;
            if (*p == '}') (*llaves_cerradas)++;
        } else if (en_comentario && *p == '*' && *(p + 1) == '/') {
            en_comentario = false;
            p++;
        } else if (en_cadena && *p == '"' && *(p - 1) != '\\') {
            en_cadena = false;
        } else if (en_caracter && *p == '\'' && *(p - 1) != '\\') {
            en_caracter = false;
        }
    }
}

// Función para limpiar espacios múltiples y normalizar
void limpiar_espacios_multiples(char* linea) {
    char temporal[MAX_LINE_LENGTH] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    bool espacio_previo = false;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                // Comentario de línea - copiar todo
                strcpy(destino, &linea[i]);
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            if (linea[i] == '\'') en_caracter = true;
            
            if (isspace(linea[i])) {
                if (!espacio_previo) {
                    *destino++ = ' ';
                    espacio_previo = true;
                }
                continue;
            } else {
                espacio_previo = false;
            }
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
            *destino++ = linea[i];
            *destino++ = linea[i+1];
            i++;
            continue;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        } else if (en_caracter && linea[i] == '\'' && (i == 0 || linea[i-1] != '\\')) {
            en_caracter = false;
        }
        
        *destino++ = linea[i];
    }
    
    *destino = '\0';
    
    // Eliminar espacios al inicio y final
    char* inicio = temporal;
    while (*inicio && isspace(*inicio)) inicio++;
    
    char* fin = inicio + strlen(inicio) - 1;
    while (fin > inicio && isspace(*fin)) fin--;
    
    *(fin + 1) = '\0';
    strcpy(linea, inicio);
}

// Función para dividir líneas largas
void dividir_linea_larga(const char* linea, char** lineas_resultado, int* num_lineas, int max_longitud) {
    if (strlen(linea) <= max_longitud) {
        strcpy(lineas_resultado[0], linea);
        *num_lineas = 1;
        return;
    }
    
    // Buscar punto de división natural
    int punto_division = -1;
    for (int i = max_longitud; i > max_longitud / 2; i--) {
        if (linea[i] == ',' || linea[i] == ';' || linea[i] == ' ' || 
            linea[i] == '(' || linea[i] == ')' || 
            strncmp(&linea[i], "&&", 2) == 0 || 
            strncmp(&linea[i], "||", 2) == 0) {
            punto_division = i;
            break;
        }
    }
    
    if (punto_division == -1) {
        // Forzar división
        punto_division = max_longitud;
    }
    
    // Dividir la línea
    strncpy(lineas_resultado[0], linea, punto_division + 1);
    lineas_resultado[0][punto_division + 1] = '\0';
    
    const char* resto = &linea[punto_division + 1];
    while (*resto && isspace(*resto)) resto++; // Saltar espacios
    
    if (*resto) {
        strcpy(lineas_resultado[1], resto);
        *num_lineas = 2;
        
        // Llamada recursiva si la segunda línea sigue siendo larga
        if (strlen(lineas_resultado[1]) > max_longitud) {
            char lineas_extra[10][MAX_LINE_LENGTH];
            int num_extra = 0;
            dividir_linea_larga(lineas_resultado[1], lineas_extra, &num_extra, max_longitud);
            
            // Reemplazar la segunda línea con las líneas divididas
            strcpy(lineas_resultado[1], lineas_extra[0]);
            for (int i = 1; i < num_extra; i++) {
                strcpy(lineas_resultado[*num_lineas], lineas_extra[i]);
                (*num_lineas)++;
            }
        }
    } else {
        *num_lineas = 1;
    }
}

// Función para separar declaraciones después de punto y coma
void separar_por_punto_coma(const char* linea, char** lineas_resultado, int* num_lineas) {
    char temporal[MAX_LINE_LENGTH] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    bool en_for = false;
    
    *num_lineas = 0;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                // Comentario de línea
                strcpy(destino, &linea[i]);
                if (strlen(temporal) > 0) {
                    strcpy(lineas_resultado[(*num_lineas)++], temporal);
                }
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            if (linea[i] == '\'') en_caracter = true;
            
            // Detectar for
            if (i >= 2 && 
                tolower(linea[i]) == 'r' && 
                tolower(linea[i-1]) == 'o' && 
                tolower(linea[i-2]) == 'f' &&
                (i-3 < 0 || !isalnum(linea[i-3]))) {
                en_for = true;
            }
            
            if (linea[i] == ';' && !en_for) {
                *destino++ = ';';
                *destino = '\0';
                
                if (strlen(temporal) > 0) {
                    strcpy(lineas_resultado[(*num_lineas)++], temporal);
                }
                
                // Resetear
                destino = temporal;
                *destino = '\0';
                continue;
            }
            
            if (linea[i] == ';' && en_for) {
                en_for = false; // Reset después del ; del for
            }
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
            *destino++ = linea[i];
            *destino++ = linea[i+1];
            i++;
            continue;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        } else if (en_caracter && linea[i] == '\'' && (i == 0 || linea[i-1] != '\\')) {
            en_caracter = false;
        }
        
        *destino++ = linea[i];
    }
    
    // Agregar última línea si queda contenido
    *destino = '\0';
    if (strlen(temporal) > 0) {
        strcpy(lineas_resultado[(*num_lineas)++], temporal);
    }
}

// Función para separar llaves en líneas independientes
void separar_llaves(const char* linea, char** lineas_resultado, int* num_lineas) {
    char temporal[MAX_LINE_LENGTH] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    
    *num_lineas = 0;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                strcpy(destino, &linea[i]);
                if (strlen(temporal) > 0) {
                    strcpy(lineas_resultado[(*num_lineas)++], temporal);
                }
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            if (linea[i] == '\'') en_caracter = true;
            
            if (linea[i] == '{' || linea[i] == '}') {
                // Guardar contenido antes de la llave
                if (destino > temporal) {
                    *destino = '\0';
                    strcpy(lineas_resultado[(*num_lineas)++], temporal);
                }
                
                // Guardar la llave como línea separada
                temporal[0] = linea[i];
                temporal[1] = '\0';
                strcpy(lineas_resultado[(*num_lineas)++], temporal);
                
                // Resetear
                destino = temporal;
                *destino = '\0';
                continue;
            }
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
            *destino++ = linea[i];
            *destino++ = linea[i+1];
            i++;
            continue;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        } else if (en_caracter && linea[i] == '\'' && (i == 0 || linea[i-1] != '\\')) {
            en_caracter = false;
        }
        
        *destino++ = linea[i];
    }
    
    // Agregar última línea si queda contenido
    *destino = '\0';
    if (strlen(temporal) > 0) {
        strcpy(lineas_resultado[(*num_lineas)++], temporal);
    }
}

// APLICAR FORMATOS ESPECÍFICOS

void aplicar_espacios_operadores(char* linea) {
    char temporal[MAX_LINE_LENGTH * 2] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                strcpy(destino, &linea[i]);
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            if (linea[i] == '\'') en_caracter = true;
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        } else if (en_caracter && linea[i] == '\'' && (i == 0 || linea[i-1] != '\\')) {
            en_caracter = false;
        }
        
        if (en_cadena || en_caracter || en_comentario) {
            *destino++ = linea[i];
            continue;
        }
        
        bool operador_procesado = false;
        
        // Operadores de 2 caracteres
        char* operadores2[] = {"==", "!=", "<=", ">=", "+=", "-=", "*=", "/=", "%=", "&&", "||"};
        for (int j = 0; j < 11; j++) {
            if (strncmp(&linea[i], operadores2[j], 2) == 0) {
                *destino++ = ' ';
                *destino++ = linea[i];
                *destino++ = linea[i+1];
                *destino++ = ' ';
                i++;
                operador_procesado = true;
                break;
            }
        }
        
        if (operador_procesado) continue;
        
        // Operadores de 1 carácter
        if (strchr("=+-*/%<>!&|", linea[i]) != NULL) {
            bool es_unario = false;
            if (i > 0) {
                char anterior = linea[i-1];
                if (strchr("(,=:[", anterior) != NULL || isspace(anterior)) {
                    es_unario = true;
                }
            }
            
            if (!es_unario) {
                *destino++ = ' ';
                *destino++ = linea[i];
                *destino++ = ' ';
                operador_procesado = true;
            } else {
                *destino++ = linea[i];
                operador_procesado = true;
            }
        }
        
        if (!operador_procesado) {
            *destino++ = linea[i];
        }
    }
    
    *destino = '\0';
    strcpy(linea, temporal);
}

void aplicar_espacio_despues_comas(char* linea) {
    char temporal[MAX_LINE_LENGTH * 2] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                strcpy(destino, &linea[i]);
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            if (linea[i] == '\'') en_caracter = true;
            
            if (linea[i] == ',') {
                *destino++ = ',';
                *destino++ = ' ';
                continue;
            }
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        } else if (en_caracter && linea[i] == '\'' && (i == 0 || linea[i-1] != '\\')) {
            en_caracter = false;
        }
        
        *destino++ = linea[i];
    }
    
    *destino = '\0';
    strcpy(linea, temporal);
}

void aplicar_espacio_antes_parentesis(char* linea) {
    char temporal[MAX_LINE_LENGTH * 2] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_comentario = false;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                strcpy(destino, &linea[i]);
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            
            if (linea[i] == '(' && i > 0) {
                const char* palabras_reservadas[] = {
                    "if", "while", "for", "switch", "return", 
                    "sizeof", "case", "default"
                };
                const int num_palabras = sizeof(palabras_reservadas) / sizeof(palabras_reservadas[0]);
                
                int j = i - 1;
                while (j >= 0 && isspace(linea[j])) j--;
                
                if (j >= 0) {
                    int inicio = j;
                    while (inicio >= 0 && (isalnum(linea[inicio]) || linea[inicio] == '_')) {
                        inicio--;
                    }
                    inicio++;
                    
                    int longitud = j - inicio + 1;
                    char palabra[50] = {0};
                    strncpy(palabra, &linea[inicio], longitud);
                    
                    for (int p = 0; p < num_palabras; p++) {
                        if (strcmp(palabra, palabras_reservadas[p]) == 0) {
                            *destino++ = ' ';
                            break;
                        }
                    }
                }
            }
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        }
        
        *destino++ = linea[i];
    }
    
    *destino = '\0';
    strcpy(linea, temporal);
}

// PRETTYPRINT PRINCIPAL MEJORADO

void formatear_codigo(const char* archivo_entrada, const char* archivo_salida, int estilo) {
    FILE* entrada = fopen(archivo_entrada, "r");
    FILE* salida = fopen(archivo_salida, "w");
    
    if (!entrada || !salida) {
        printf("❌ Error: No se pudo abrir los archivos\n");
        if (entrada) fclose(entrada);
        if (salida) fclose(salida);
        return;
    }

    // Configurar estilo
    ConfiguracionEstilo config;
    switch (estilo) {
        case 1: configurar_estilo_gnu(&config); break;
        case 2: configurar_estilo_bsd(&config); break;
        case 3: configurar_estilo_personalizado(&config); break;
        default: configurar_estilo_personalizado(&config); break;
    }

    // FASE 1: Leer y limpiar completamente el código
    char lineas_limpias[MAX_LINEAS][MAX_LINE_LENGTH];
    int num_lineas_limpias = 0;
    bool en_comentario_multilinea = false;
    char acumulador_multilinea[MAX_LINE_LENGTH] = {0};
    
    char linea[MAX_LINE_LENGTH];
    while (fgets(linea, sizeof(linea), entrada)) {
        // Eliminar retornos de carro y newlines
        linea[strcspn(linea, "\r\n")] = '\0';
        
        char* linea_limpia = linea;
        while (*linea_limpia && isspace(*linea_limpia)) linea_limpia++;
        
        // Manejar comentarios multilínea
        if (en_comentario_multilinea) {
            strcat(acumulador_multilinea, " ");
            strcat(acumulador_multilinea, linea_limpia);
            
            if (strstr(linea_limpia, "*/")) {
                strcpy(lineas_limpias[num_lineas_limpias++], acumulador_multilinea);
                en_comentario_multilinea = false;
                acumulador_multilinea[0] = '\0';
            }
            continue;
        }
        
        if (strstr(linea_limpia, "/*")) {
            en_comentario_multilinea = true;
            strcpy(acumulador_multilinea, linea_limpia);
            if (strstr(linea_limpia, "*/")) {
                strcpy(lineas_limpias[num_lineas_limpias++], acumulador_multilinea);
                en_comentario_multilinea = false;
                acumulador_multilinea[0] = '\0';
            }
            continue;
        }
        
        // Saltar líneas completamente vacías
        if (strlen(linea_limpia) == 0) continue;
        
        // Limpiar espacios múltiples y normalizar
        limpiar_espacios_multiples(linea_limpia);
        
        if (strlen(linea_limpia) > 0) {
            strcpy(lineas_limpias[num_lineas_limpias++], linea_limpia);
        }
    }
    fclose(entrada);
    
    // FASE 2: Procesar y formatear
    int nivel_indentacion = 0;
    bool funcion_anterior_cerrada = false;
    
    for (int i = 0; i < num_lineas_limpias; i++) {
        char* linea_actual = lineas_limpias[i];
        
        // Saltar líneas vacías después de procesar
        if (strlen(linea_actual) == 0) continue;
        
        // Directivas de preprocesador sin cambios
        if (es_directiva_preprocesador(linea_actual)) {
            fputs(linea_actual, salida);
            fputc('\n', salida);
            if (config.lineas_vacias_entre_funciones && i < num_lineas_limpias - 1) {
                char* siguiente = lineas_limpias[i + 1];
                if (!es_directiva_preprocesador(siguiente) && 
                    !es_linea_comentario(siguiente) &&
                    strstr(siguiente, "{")) {
                    fputc('\n', salida);
                }
            }
            continue;
        }
        
        // Comentarios sin cambios (excepto limpieza de espacios)
        if (es_linea_comentario(linea_actual)) {
            aplicar_indentacion(salida, nivel_indentacion, config.tamano_indentacion);
            fputs(linea_actual, salida);
            fputc('\n', salida);
            continue;
        }
        
        // FASE 3: Aplicar transformaciones según el estilo
        char linea_formateada[MAX_LINE_LENGTH];
        strcpy(linea_formateada, linea_actual);
        
        // Separar llaves primero
        char* lineas_separadas[10];
        int num_separadas = 0;
        for (int j = 0; j < 10; j++) {
            lineas_separadas[j] = malloc(MAX_LINE_LENGTH);
        }
        
        separar_llaves(linea_formateada, lineas_separadas, &num_separadas);
        
        // Procesar cada línea separada
        for (int j = 0; j < num_separadas; j++) {
            char linea_procesada[MAX_LINE_LENGTH];
            strcpy(linea_procesada, lineas_separadas[j]);
            
            // Aplicar formato específico
            if (config.espacios_alrededor_operadores) {
                aplicar_espacios_operadores(linea_procesada);
            }
            
            if (config.espacio_despues_comas) {
                aplicar_espacio_despues_comas(linea_procesada);
            }
            
            if (config.espacio_antes_parentesis) {
                aplicar_espacio_antes_parentesis(linea_procesada);
            }
            
            // Limpiar nuevamente después de aplicar formatos
            limpiar_espacios_multiples(linea_procesada);
            
            // Manejar punto y coma
            if (config.salto_linea_despues_punto_coma && 
                strlen(linea_procesada) > 0 && 
                strchr(linea_procesada, ';') != NULL &&
                strcmp(linea_procesada, ";") != 0) {
                
                char* lineas_por_punto_coma[10];
                int num_por_punto_coma = 0;
                for (int k = 0; k < 10; k++) {
                    lineas_por_punto_coma[k] = malloc(MAX_LINE_LENGTH);
                }
                
                separar_por_punto_coma(linea_procesada, lineas_por_punto_coma, &num_por_punto_coma);
                
                for (int k = 0; k < num_por_punto_coma; k++) {
                    char linea_final[MAX_LINE_LENGTH];
                    strcpy(linea_final, lineas_por_punto_coma[k]);
                    
                    // Dividir líneas largas
                    if (strlen(linea_final) > config.max_longitud_linea) {
                        char* lineas_divididas[10];
                        int num_divididas = 0;
                        for (int m = 0; m < 10; m++) {
                            lineas_divididas[m] = malloc(MAX_LINE_LENGTH);
                        }
                        
                        dividir_linea_larga(linea_final, lineas_divididas, &num_divididas, config.max_longitud_linea);
                        
                        for (int m = 0; m < num_divididas; m++) {
                            procesar_y_escribir_linea(lineas_divididas[m], salida, &nivel_indentacion, config, &funcion_anterior_cerrada);
                        }
                        
                        for (int m = 0; m < 10; m++) free(lineas_divididas[m]);
                    } else {
                        procesar_y_escribir_linea(linea_final, salida, &nivel_indentacion, config, &funcion_anterior_cerrada);
                    }
                }
                
                for (int k = 0; k < 10; k++) free(lineas_por_punto_coma[k]);
            } else {
                // Dividir líneas largas
                if (strlen(linea_procesada) > config.max_longitud_linea) {
                    char* lineas_divididas[10];
                    int num_divididas = 0;
                    for (int k = 0; k < 10; k++) {
                        lineas_divididas[k] = malloc(MAX_LINE_LENGTH);
                    }
                    
                    dividir_linea_larga(linea_procesada, lineas_divididas, &num_divididas, config.max_longitud_linea);
                    
                    for (int k = 0; k < num_divididas; k++) {
                        procesar_y_escribir_linea(lineas_divididas[k], salida, &nivel_indentacion, config, &funcion_anterior_cerrada);
                    }
                    
                    for (int k = 0; k < 10; k++) free(lineas_divididas[k]);
                } else {
                    procesar_y_escribir_linea(linea_procesada, salida, &nivel_indentacion, config, &funcion_anterior_cerrada);
                }
            }
        }
        
        for (int j = 0; j < 10; j++) free(lineas_separadas[j]);
        
        // Línea vacía entre funciones si está configurado
        if (config.lineas_vacias_entre_funciones && funcion_anterior_cerrada && 
            i < num_lineas_limpias - 1 && nivel_indentacion == 0) {
            char* siguiente = lineas_limpias[i + 1];
            if (!es_directiva_preprocesador(siguiente) && 
                !es_linea_comentario(siguiente) &&
                strlen(siguiente) > 0) {
                fputc('\n', salida);
            }
            funcion_anterior_cerrada = false;
        }
    }
    
    fclose(salida);
}

// Función auxiliar para procesar y escribir una línea con el formato correcto
void procesar_y_escribir_linea(char* linea, FILE* salida, int* nivel_indentacion, 
                               ConfiguracionEstilo config, bool* funcion_anterior_cerrada) {
    if (strlen(linea) == 0) return;
    
    // Contar llaves para esta línea
    int llaves_abiertas = 0, llaves_cerradas = 0;
    contar_llaves(linea, &llaves_abiertas, &llaves_cerradas);
    
    // Ajustar indentación para llaves de cierre
    int indentacion_actual = *nivel_indentacion;
    if (llaves_cerradas > 0) {
        indentacion_actual = *nivel_indentacion - llaves_cerradas;
        if (indentacion_actual < 0) indentacion_actual = 0;
    }
    
    // Manejar estilo de llaves
    if (strcmp(linea, "{") == 0 && config.estilo_llaves == 1) {
        // Llave en línea propia
        aplicar_indentacion(salida, indentacion_actual, config.tamano_indentacion);
        fputs("{\n", salida);
    } else if (strchr(linea, '{') != NULL && config.estilo_llaves == 1) {
        // Separar contenido antes de la llave
        char* pos_llave = strchr(linea, '{');
        int indice = pos_llave - linea;
        
        char antes_llave[MAX_LINE_LENGTH] = {0};
        strncpy(antes_llave, linea, indice);
        antes_llave[indice] = '\0';
        
        // Escribir línea antes de llave
        if (strlen(antes_llave) > 0) {
            aplicar_indentacion(salida, indentacion_actual, config.tamano_indentacion);
            fputs(antes_llave, salida);
            fputc('\n', salida);
        }
        
        // Escribir llave en línea separada
        aplicar_indentacion(salida, indentacion_actual, config.tamano_indentacion);
        fputs("{\n", salida);
    } else {
        // Escribir línea normalmente
        aplicar_indentacion(salida, indentacion_actual, config.tamano_indentacion);
        fputs(linea, salida);
        fputc('\n', salida);
    }
    
    // Actualizar nivel de indentación
    *nivel_indentacion += llaves_abiertas - llaves_cerradas;
    if (*nivel_indentacion < 0) *nivel_indentacion = 0;
    
    // Marcar si se cerró una función
    if (llaves_cerradas > 0 && *nivel_indentacion == 0) {
        *funcion_anterior_cerrada = true;
    }
}