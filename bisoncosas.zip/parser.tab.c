/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "parser.y"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void yyerror(const char *s);
int yylex(void);

extern FILE *yyin;

/* Variables globales para el manejo de errores */
char *filename = NULL;

#line 86 "parser.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_TOKEN_AUTO = 3,                 /* TOKEN_AUTO  */
  YYSYMBOL_TOKEN_DEFINE = 4,               /* TOKEN_DEFINE  */
  YYSYMBOL_TOKEN_INCLUDE = 5,              /* TOKEN_INCLUDE  */
  YYSYMBOL_TOKEN_BREAK = 6,                /* TOKEN_BREAK  */
  YYSYMBOL_TOKEN_CASE = 7,                 /* TOKEN_CASE  */
  YYSYMBOL_TOKEN_CHAR = 8,                 /* TOKEN_CHAR  */
  YYSYMBOL_TOKEN_CONST = 9,                /* TOKEN_CONST  */
  YYSYMBOL_TOKEN_CONTINUE = 10,            /* TOKEN_CONTINUE  */
  YYSYMBOL_TOKEN_DEFAULT = 11,             /* TOKEN_DEFAULT  */
  YYSYMBOL_TOKEN_DO = 12,                  /* TOKEN_DO  */
  YYSYMBOL_TOKEN_DOUBLE = 13,              /* TOKEN_DOUBLE  */
  YYSYMBOL_TOKEN_ELSE = 14,                /* TOKEN_ELSE  */
  YYSYMBOL_TOKEN_ENUM = 15,                /* TOKEN_ENUM  */
  YYSYMBOL_TOKEN_EXTERN = 16,              /* TOKEN_EXTERN  */
  YYSYMBOL_TOKEN_FLOAT = 17,               /* TOKEN_FLOAT  */
  YYSYMBOL_TOKEN_FOR = 18,                 /* TOKEN_FOR  */
  YYSYMBOL_TOKEN_GOTO = 19,                /* TOKEN_GOTO  */
  YYSYMBOL_TOKEN_IF = 20,                  /* TOKEN_IF  */
  YYSYMBOL_TOKEN_INT = 21,                 /* TOKEN_INT  */
  YYSYMBOL_TOKEN_LONG = 22,                /* TOKEN_LONG  */
  YYSYMBOL_TOKEN_REGISTER = 23,            /* TOKEN_REGISTER  */
  YYSYMBOL_TOKEN_RETURN = 24,              /* TOKEN_RETURN  */
  YYSYMBOL_TOKEN_SHORT = 25,               /* TOKEN_SHORT  */
  YYSYMBOL_TOKEN_SIGNED = 26,              /* TOKEN_SIGNED  */
  YYSYMBOL_TOKEN_SIZEOF = 27,              /* TOKEN_SIZEOF  */
  YYSYMBOL_TOKEN_STATIC = 28,              /* TOKEN_STATIC  */
  YYSYMBOL_TOKEN_STRUCT = 29,              /* TOKEN_STRUCT  */
  YYSYMBOL_TOKEN_SWITCH = 30,              /* TOKEN_SWITCH  */
  YYSYMBOL_TOKEN_TYPEDEF = 31,             /* TOKEN_TYPEDEF  */
  YYSYMBOL_TOKEN_UNION = 32,               /* TOKEN_UNION  */
  YYSYMBOL_TOKEN_UNSIGNED = 33,            /* TOKEN_UNSIGNED  */
  YYSYMBOL_TOKEN_VOID = 34,                /* TOKEN_VOID  */
  YYSYMBOL_TOKEN_VOLATILE = 35,            /* TOKEN_VOLATILE  */
  YYSYMBOL_TOKEN_WHILE = 36,               /* TOKEN_WHILE  */
  YYSYMBOL_TOKEN_ID = 37,                  /* TOKEN_ID  */
  YYSYMBOL_TOKEN_CONST_ENTERO = 38,        /* TOKEN_CONST_ENTERO  */
  YYSYMBOL_TOKEN_CONST_FLOTANTE = 39,      /* TOKEN_CONST_FLOTANTE  */
  YYSYMBOL_TOKEN_CONST_CARACTER = 40,      /* TOKEN_CONST_CARACTER  */
  YYSYMBOL_TOKEN_CONST_CADENA = 41,        /* TOKEN_CONST_CADENA  */
  YYSYMBOL_TOKEN_ADD_ASSIGN = 42,          /* TOKEN_ADD_ASSIGN  */
  YYSYMBOL_TOKEN_SUB_ASSIGN = 43,          /* TOKEN_SUB_ASSIGN  */
  YYSYMBOL_TOKEN_MUL_ASSIGN = 44,          /* TOKEN_MUL_ASSIGN  */
  YYSYMBOL_TOKEN_DIV_ASSIGN = 45,          /* TOKEN_DIV_ASSIGN  */
  YYSYMBOL_TOKEN_MOD_ASSIGN = 46,          /* TOKEN_MOD_ASSIGN  */
  YYSYMBOL_TOKEN_SHL_ASSIGN = 47,          /* TOKEN_SHL_ASSIGN  */
  YYSYMBOL_TOKEN_SHR_ASSIGN = 48,          /* TOKEN_SHR_ASSIGN  */
  YYSYMBOL_TOKEN_AND_ASSIGN = 49,          /* TOKEN_AND_ASSIGN  */
  YYSYMBOL_TOKEN_XOR_ASSIGN = 50,          /* TOKEN_XOR_ASSIGN  */
  YYSYMBOL_TOKEN_OR_ASSIGN = 51,           /* TOKEN_OR_ASSIGN  */
  YYSYMBOL_TOKEN_INC = 52,                 /* TOKEN_INC  */
  YYSYMBOL_TOKEN_DEC = 53,                 /* TOKEN_DEC  */
  YYSYMBOL_TOKEN_TERN_IF = 54,             /* TOKEN_TERN_IF  */
  YYSYMBOL_TOKEN_MAS = 55,                 /* TOKEN_MAS  */
  YYSYMBOL_TOKEN_MOD = 56,                 /* TOKEN_MOD  */
  YYSYMBOL_TOKEN_MENOS = 57,               /* TOKEN_MENOS  */
  YYSYMBOL_TOKEN_MULT = 58,                /* TOKEN_MULT  */
  YYSYMBOL_TOKEN_DIV = 59,                 /* TOKEN_DIV  */
  YYSYMBOL_TOKEN_ASIGN = 60,               /* TOKEN_ASIGN  */
  YYSYMBOL_TOKEN_IGUAL = 61,               /* TOKEN_IGUAL  */
  YYSYMBOL_TOKEN_DIF = 62,                 /* TOKEN_DIF  */
  YYSYMBOL_TOKEN_MENOR = 63,               /* TOKEN_MENOR  */
  YYSYMBOL_TOKEN_MAYOR = 64,               /* TOKEN_MAYOR  */
  YYSYMBOL_TOKEN_MENOR_IGUAL = 65,         /* TOKEN_MENOR_IGUAL  */
  YYSYMBOL_TOKEN_MAYOR_IGUAL = 66,         /* TOKEN_MAYOR_IGUAL  */
  YYSYMBOL_TOKEN_AND = 67,                 /* TOKEN_AND  */
  YYSYMBOL_TOKEN_OR = 68,                  /* TOKEN_OR  */
  YYSYMBOL_TOKEN_NOT = 69,                 /* TOKEN_NOT  */
  YYSYMBOL_TOKEN_AND_BIT = 70,             /* TOKEN_AND_BIT  */
  YYSYMBOL_TOKEN_OR_BIT = 71,              /* TOKEN_OR_BIT  */
  YYSYMBOL_TOKEN_XOR = 72,                 /* TOKEN_XOR  */
  YYSYMBOL_TOKEN_DESPL_IZQ = 73,           /* TOKEN_DESPL_IZQ  */
  YYSYMBOL_TOKEN_DESPL_DER = 74,           /* TOKEN_DESPL_DER  */
  YYSYMBOL_TOKEN_PUNTO_COMA = 75,          /* TOKEN_PUNTO_COMA  */
  YYSYMBOL_TOKEN_DOS_PUNTO = 76,           /* TOKEN_DOS_PUNTO  */
  YYSYMBOL_TOKEN_GATO = 77,                /* TOKEN_GATO  */
  YYSYMBOL_TOKEN_COMA = 78,                /* TOKEN_COMA  */
  YYSYMBOL_TOKEN_TILDE = 79,               /* TOKEN_TILDE  */
  YYSYMBOL_TOKEN_PARENT_IZQ = 80,          /* TOKEN_PARENT_IZQ  */
  YYSYMBOL_TOKEN_PARENT_DER = 81,          /* TOKEN_PARENT_DER  */
  YYSYMBOL_TOKEN_LLAVE_IZQ = 82,           /* TOKEN_LLAVE_IZQ  */
  YYSYMBOL_TOKEN_LLAVE_DER = 83,           /* TOKEN_LLAVE_DER  */
  YYSYMBOL_TOKEN_CORCH_IZQ = 84,           /* TOKEN_CORCH_IZQ  */
  YYSYMBOL_TOKEN_CORCH_DER = 85,           /* TOKEN_CORCH_DER  */
  YYSYMBOL_TOKEN_PUNTO = 86,               /* TOKEN_PUNTO  */
  YYSYMBOL_TOKEN_FLECHA = 87,              /* TOKEN_FLECHA  */
  YYSYMBOL_TOKEN_ERROR = 88,               /* TOKEN_ERROR  */
  YYSYMBOL_LOWER_THAN_ELSE = 89,           /* LOWER_THAN_ELSE  */
  YYSYMBOL_YYACCEPT = 90,                  /* $accept  */
  YYSYMBOL_programa = 91,                  /* programa  */
  YYSYMBOL_unidades_traduccion = 92,       /* unidades_traduccion  */
  YYSYMBOL_unidad_traduccion = 93,         /* unidad_traduccion  */
  YYSYMBOL_directiva_preprocesador = 94,   /* directiva_preprocesador  */
  YYSYMBOL_declaracion_externa = 95,       /* declaracion_externa  */
  YYSYMBOL_declaracion_variable = 96,      /* declaracion_variable  */
  YYSYMBOL_especificador_declaracion = 97, /* especificador_declaracion  */
  YYSYMBOL_calificador = 98,               /* calificador  */
  YYSYMBOL_tipo_simple = 99,               /* tipo_simple  */
  YYSYMBOL_punteros_opcionales = 100,      /* punteros_opcionales  */
  YYSYMBOL_lista_declaradores = 101,       /* lista_declaradores  */
  YYSYMBOL_declarador = 102,               /* declarador  */
  YYSYMBOL_declarador_directo = 103,       /* declarador_directo  */
  YYSYMBOL_inicializador = 104,            /* inicializador  */
  YYSYMBOL_lista_inicializadores = 105,    /* lista_inicializadores  */
  YYSYMBOL_definicion_funcion = 106,       /* definicion_funcion  */
  YYSYMBOL_lista_parametros = 107,         /* lista_parametros  */
  YYSYMBOL_parametro = 108,                /* parametro  */
  YYSYMBOL_declaracion_struct = 109,       /* declaracion_struct  */
  YYSYMBOL_miembros_struct = 110,          /* miembros_struct  */
  YYSYMBOL_miembro_struct = 111,           /* miembro_struct  */
  YYSYMBOL_lista_declaradores_struct = 112, /* lista_declaradores_struct  */
  YYSYMBOL_declaracion_enum = 113,         /* declaracion_enum  */
  YYSYMBOL_lista_enumeradores = 114,       /* lista_enumeradores  */
  YYSYMBOL_enumerador = 115,               /* enumerador  */
  YYSYMBOL_sentencia = 116,                /* sentencia  */
  YYSYMBOL_sentencia_expresion = 117,      /* sentencia_expresion  */
  YYSYMBOL_bloque_compuesto = 118,         /* bloque_compuesto  */
  YYSYMBOL_lista_sentencias = 119,         /* lista_sentencias  */
  YYSYMBOL_sentencia_if = 120,             /* sentencia_if  */
  YYSYMBOL_sentencia_switch = 121,         /* sentencia_switch  */
  YYSYMBOL_sentencia_while = 122,          /* sentencia_while  */
  YYSYMBOL_sentencia_do = 123,             /* sentencia_do  */
  YYSYMBOL_sentencia_for = 124,            /* sentencia_for  */
  YYSYMBOL_expresion_for_init = 125,       /* expresion_for_init  */
  YYSYMBOL_expresion_opcional = 126,       /* expresion_opcional  */
  YYSYMBOL_sentencia_salto = 127,          /* sentencia_salto  */
  YYSYMBOL_sentencia_case = 128,           /* sentencia_case  */
  YYSYMBOL_sentencia_default = 129,        /* sentencia_default  */
  YYSYMBOL_expresion = 130,                /* expresion  */
  YYSYMBOL_expresion_asignacion = 131,     /* expresion_asignacion  */
  YYSYMBOL_operador_asignacion = 132,      /* operador_asignacion  */
  YYSYMBOL_expresion_condicional = 133,    /* expresion_condicional  */
  YYSYMBOL_expresion_logica_or = 134,      /* expresion_logica_or  */
  YYSYMBOL_expresion_logica_and = 135,     /* expresion_logica_and  */
  YYSYMBOL_expresion_or_bit = 136,         /* expresion_or_bit  */
  YYSYMBOL_expresion_xor_bit = 137,        /* expresion_xor_bit  */
  YYSYMBOL_expresion_and_bit = 138,        /* expresion_and_bit  */
  YYSYMBOL_expresion_igualdad = 139,       /* expresion_igualdad  */
  YYSYMBOL_expresion_relacional = 140,     /* expresion_relacional  */
  YYSYMBOL_expresion_desplazamiento = 141, /* expresion_desplazamiento  */
  YYSYMBOL_expresion_aditiva = 142,        /* expresion_aditiva  */
  YYSYMBOL_expresion_multiplicativa = 143, /* expresion_multiplicativa  */
  YYSYMBOL_expresion_cast = 144,           /* expresion_cast  */
  YYSYMBOL_expresion_unaria = 145,         /* expresion_unaria  */
  YYSYMBOL_operador_unario = 146,          /* operador_unario  */
  YYSYMBOL_expresion_postfija = 147,       /* expresion_postfija  */
  YYSYMBOL_lista_argumentos = 148,         /* lista_argumentos  */
  YYSYMBOL_expresion_primaria = 149        /* expresion_primaria  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if 1

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* 1 */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
             && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  46
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   965

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  90
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  60
/* YYNRULES -- Number of rules.  */
#define YYNRULES  202
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  349

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   344


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   106,   106,   108,   112,   113,   117,   118,   125,   126,
     127,   128,   135,   136,   140,   141,   142,   147,   148,   149,
     150,   154,   155,   156,   157,   158,   159,   163,   164,   165,
     166,   167,   168,   169,   170,   171,   172,   173,   174,   175,
     176,   177,   178,   179,   180,   181,   182,   185,   187,   188,
     189,   193,   194,   198,   199,   203,   204,   205,   209,   210,
     211,   215,   216,   223,   224,   225,   226,   230,   231,   235,
     236,   237,   238,   239,   240,   247,   248,   252,   253,   257,
     258,   262,   263,   267,   268,   272,   273,   277,   278,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     299,   300,   304,   305,   309,   310,   317,   318,   322,   326,
     330,   334,   337,   339,   340,   341,   344,   346,   353,   354,
     355,   356,   357,   361,   362,   366,   367,   374,   375,   379,
     380,   384,   385,   386,   387,   388,   389,   390,   391,   392,
     393,   394,   398,   399,   403,   404,   408,   409,   413,   414,
     418,   419,   423,   424,   428,   429,   430,   434,   435,   436,
     437,   438,   442,   443,   444,   448,   449,   450,   454,   455,
     456,   457,   461,   462,   463,   467,   468,   469,   470,   471,
     472,   476,   477,   478,   479,   480,   481,   485,   486,   487,
     488,   489,   490,   491,   492,   496,   497,   501,   502,   503,
     504,   505,   506
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if 1
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "TOKEN_AUTO",
  "TOKEN_DEFINE", "TOKEN_INCLUDE", "TOKEN_BREAK", "TOKEN_CASE",
  "TOKEN_CHAR", "TOKEN_CONST", "TOKEN_CONTINUE", "TOKEN_DEFAULT",
  "TOKEN_DO", "TOKEN_DOUBLE", "TOKEN_ELSE", "TOKEN_ENUM", "TOKEN_EXTERN",
  "TOKEN_FLOAT", "TOKEN_FOR", "TOKEN_GOTO", "TOKEN_IF", "TOKEN_INT",
  "TOKEN_LONG", "TOKEN_REGISTER", "TOKEN_RETURN", "TOKEN_SHORT",
  "TOKEN_SIGNED", "TOKEN_SIZEOF", "TOKEN_STATIC", "TOKEN_STRUCT",
  "TOKEN_SWITCH", "TOKEN_TYPEDEF", "TOKEN_UNION", "TOKEN_UNSIGNED",
  "TOKEN_VOID", "TOKEN_VOLATILE", "TOKEN_WHILE", "TOKEN_ID",
  "TOKEN_CONST_ENTERO", "TOKEN_CONST_FLOTANTE", "TOKEN_CONST_CARACTER",
  "TOKEN_CONST_CADENA", "TOKEN_ADD_ASSIGN", "TOKEN_SUB_ASSIGN",
  "TOKEN_MUL_ASSIGN", "TOKEN_DIV_ASSIGN", "TOKEN_MOD_ASSIGN",
  "TOKEN_SHL_ASSIGN", "TOKEN_SHR_ASSIGN", "TOKEN_AND_ASSIGN",
  "TOKEN_XOR_ASSIGN", "TOKEN_OR_ASSIGN", "TOKEN_INC", "TOKEN_DEC",
  "TOKEN_TERN_IF", "TOKEN_MAS", "TOKEN_MOD", "TOKEN_MENOS", "TOKEN_MULT",
  "TOKEN_DIV", "TOKEN_ASIGN", "TOKEN_IGUAL", "TOKEN_DIF", "TOKEN_MENOR",
  "TOKEN_MAYOR", "TOKEN_MENOR_IGUAL", "TOKEN_MAYOR_IGUAL", "TOKEN_AND",
  "TOKEN_OR", "TOKEN_NOT", "TOKEN_AND_BIT", "TOKEN_OR_BIT", "TOKEN_XOR",
  "TOKEN_DESPL_IZQ", "TOKEN_DESPL_DER", "TOKEN_PUNTO_COMA",
  "TOKEN_DOS_PUNTO", "TOKEN_GATO", "TOKEN_COMA", "TOKEN_TILDE",
  "TOKEN_PARENT_IZQ", "TOKEN_PARENT_DER", "TOKEN_LLAVE_IZQ",
  "TOKEN_LLAVE_DER", "TOKEN_CORCH_IZQ", "TOKEN_CORCH_DER", "TOKEN_PUNTO",
  "TOKEN_FLECHA", "TOKEN_ERROR", "LOWER_THAN_ELSE", "$accept", "programa",
  "unidades_traduccion", "unidad_traduccion", "directiva_preprocesador",
  "declaracion_externa", "declaracion_variable",
  "especificador_declaracion", "calificador", "tipo_simple",
  "punteros_opcionales", "lista_declaradores", "declarador",
  "declarador_directo", "inicializador", "lista_inicializadores",
  "definicion_funcion", "lista_parametros", "parametro",
  "declaracion_struct", "miembros_struct", "miembro_struct",
  "lista_declaradores_struct", "declaracion_enum", "lista_enumeradores",
  "enumerador", "sentencia", "sentencia_expresion", "bloque_compuesto",
  "lista_sentencias", "sentencia_if", "sentencia_switch",
  "sentencia_while", "sentencia_do", "sentencia_for", "expresion_for_init",
  "expresion_opcional", "sentencia_salto", "sentencia_case",
  "sentencia_default", "expresion", "expresion_asignacion",
  "operador_asignacion", "expresion_condicional", "expresion_logica_or",
  "expresion_logica_and", "expresion_or_bit", "expresion_xor_bit",
  "expresion_and_bit", "expresion_igualdad", "expresion_relacional",
  "expresion_desplazamiento", "expresion_aditiva",
  "expresion_multiplicativa", "expresion_cast", "expresion_unaria",
  "operador_unario", "expresion_postfija", "lista_argumentos",
  "expresion_primaria", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-218)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     639,  -218,  -218,  -218,  -218,   -27,  -218,  -218,  -218,    -3,
    -218,  -218,     8,  -218,   -24,   112,  -218,  -218,    66,    41,
     639,  -218,  -218,  -218,  -218,    48,   930,    48,  -218,   -48,
     -44,    17,    75,  -218,  -218,  -218,  -218,  -218,    49,   930,
    -218,  -218,  -218,  -218,   101,   -26,  -218,  -218,   108,   149,
       9,  -218,   153,   178,   930,  -218,   185,  -218,  -218,    75,
     171,   -55,  -218,   930,    48,    48,   373,  -218,   210,  -218,
     212,   201,   -31,   200,  -218,    48,  -218,  -218,   172,  -218,
     181,   -18,   224,    75,  -218,   401,   226,    27,    44,  -218,
    -218,  -218,   179,  -218,   510,   -29,   706,   226,  -218,  -218,
     538,  -218,  -218,  -218,  -218,   -33,  -218,  -218,    48,  -218,
     227,   186,    48,    48,    43,  -218,   182,  -218,   818,  -218,
    -218,  -218,  -218,  -218,   825,   825,  -218,  -218,  -218,  -218,
    -218,  -218,   662,   706,  -218,  -218,  -218,   -30,   206,   219,
     221,   225,    13,    16,    18,    72,     3,  -218,   234,   862,
      24,  -218,   186,    47,   226,   245,   217,  -218,   254,   289,
     930,   186,  -218,   662,  -218,   862,  -218,  -218,   -46,    87,
    -218,  -218,   -10,   862,   862,   862,   862,   862,   862,   862,
     862,   862,   862,   862,   862,   862,   862,   862,   862,   862,
     862,   862,  -218,  -218,  -218,  -218,  -218,  -218,  -218,  -218,
    -218,  -218,  -218,   862,  -218,  -218,  -218,  -218,   740,   862,
     290,   300,  -218,   186,  -218,  -218,   263,   862,   264,   265,
     442,   260,   305,   266,   774,   269,   271,  -218,  -218,  -218,
      48,  -218,  -218,  -218,  -218,   295,  -218,  -218,  -218,  -218,
    -218,  -218,  -218,  -218,   103,   259,   261,  -218,  -218,   273,
     274,   862,   862,  -218,   670,  -218,   126,   206,   219,   221,
     225,    13,    16,    16,    18,    18,    18,    18,    72,    72,
       3,     3,  -218,  -218,  -218,  -218,  -218,  -218,   110,   -53,
    -218,  -218,  -218,  -218,   268,  -218,   442,   320,   571,   282,
     862,  -218,   117,   862,   862,  -218,  -218,  -218,   275,   276,
    -218,   862,  -218,  -218,  -218,  -218,   862,   862,  -218,  -218,
     442,  -218,   278,    48,    48,   284,   285,  -218,   118,  -218,
     122,   130,  -218,  -218,  -218,  -218,  -218,  -218,   862,   288,
     288,   862,   442,   442,   442,   131,   287,   285,   353,  -218,
    -218,   293,   862,   442,  -218,   291,  -218,   442,  -218
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       2,    25,    28,    21,    33,     0,    23,    32,    30,    31,
      26,    29,    34,    22,     0,    35,    27,    24,     0,     0,
       3,     4,     6,     7,    12,    47,     0,    17,    13,     0,
       0,    46,     0,    44,    36,    38,    42,    40,    45,     0,
      37,    39,    43,    41,     0,     0,     1,     5,    48,     0,
       0,    51,     0,     0,     0,    18,     0,    15,    16,     0,
      87,     0,    85,     0,    47,    17,     0,    77,    10,     8,
       0,    49,    55,    53,    14,    47,    46,    45,     0,    19,
       0,     0,     0,     0,    84,     0,     0,     0,     0,    76,
      78,    11,     0,    50,     0,     0,     0,     0,    52,    20,
       0,    83,    88,    86,    75,    55,    81,    79,    47,    80,
       0,     0,    47,    17,     0,    67,     0,    57,     0,   197,
     198,   199,   200,   201,     0,     0,   183,   184,   182,   186,
     181,   185,     0,     0,    54,    58,   129,   142,   144,   146,
     148,   150,   152,   154,   157,   162,   165,   168,   172,     0,
     175,   187,     0,     0,     0,     0,     0,    64,    71,    74,
       0,     0,    56,     0,   179,     0,   176,   177,     0,     0,
     127,    61,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   132,   133,   134,   135,   136,   137,   138,   139,
     140,   141,   131,     0,   178,   172,   193,   194,     0,     0,
       0,     0,    66,     0,    82,     9,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   100,   102,    99,
      47,    17,   104,    89,    90,     0,    91,    92,    93,    94,
      95,    96,    97,    98,     0,    69,    72,    68,    63,     0,
       0,     0,     0,   202,     0,    59,     0,   145,   147,   149,
     151,   153,   155,   156,   158,   159,   160,   161,   163,   164,
     166,   167,   171,   169,   170,   130,   189,   195,     0,     0,
     191,   192,    65,   120,     0,   119,   125,     0,   112,     0,
       0,   121,     0,     0,     0,   103,   105,   101,     0,     0,
     180,     0,   173,   128,    60,    62,     0,     0,   190,   188,
     123,   126,     0,    47,    17,     0,   113,   118,     0,   122,
       0,     0,    70,    73,   174,   143,   196,   124,     0,   114,
     115,   116,     0,     0,     0,     0,     0,   117,   106,   108,
     109,     0,   116,     0,   110,     0,   107,     0,   111
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -218,  -218,  -218,   349,  -218,  -218,    14,     1,    -4,     0,
      71,  -155,   296,   -82,  -131,  -218,  -218,   279,   213,  -218,
     317,   -49,   318,  -218,   325,   302,  -217,  -218,  -104,  -218,
    -218,  -218,  -218,  -218,  -218,  -218,    45,  -218,  -218,  -218,
    -121,   -90,  -218,  -209,  -218,   218,   216,   229,   220,   215,
      -9,    -7,    28,    31,  -144,   -35,  -218,  -218,  -218,  -218
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,    19,    20,    21,    22,    23,   229,   230,    26,   231,
      97,    50,    51,    73,   134,   172,    28,   114,   115,    29,
      66,    67,    87,    30,    61,    62,   232,   233,   234,   235,
     236,   237,   238,   239,   240,   315,   336,   241,   242,   243,
     244,   170,   203,   136,   137,   138,   139,   140,   141,   142,
     143,   144,   145,   146,   147,   148,   149,   150,   278,   151
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      27,    25,   171,   287,   106,   204,   135,   157,   284,   116,
      31,   169,   250,    38,    24,    69,    34,    90,   296,    33,
      27,    25,    54,    83,   173,   252,    55,    57,    84,    35,
      36,    58,   309,    37,    24,   251,    90,    70,   174,    65,
      64,    46,   169,   135,   169,   272,   273,   274,   212,    94,
      78,    95,   256,    95,    79,    32,   117,   248,    39,   189,
      83,   190,   191,    65,    64,   101,    65,    64,   254,   311,
      44,    45,   214,   255,   179,   180,   206,   207,    99,   181,
     182,   183,   184,   164,    74,    65,    64,    75,   279,   166,
     167,   185,   186,   327,   113,   112,    49,   325,    56,    59,
     113,   112,   107,   292,   208,   108,    48,   302,   209,   282,
     210,   211,    60,   275,   205,   338,   339,   340,   277,   109,
      40,   160,   108,   305,   161,   160,   346,   187,   213,   188,
     348,    63,   168,    41,    42,    86,    86,    43,    68,   205,
     205,   205,   205,   205,   205,   205,   205,   205,   205,   205,
     205,   205,   205,   205,   205,   205,   205,   324,   329,   330,
     113,   112,   303,   249,   135,   252,    71,   316,   253,   318,
     262,   263,   320,   321,   264,   265,   266,   267,   297,   154,
       2,   252,   205,   158,   159,     4,    72,    52,   307,     7,
      76,   308,   319,     8,     9,   252,   252,    11,    12,   332,
     252,    53,   306,   333,   252,    15,    16,   335,   252,   252,
     337,   334,   341,   268,   269,    77,   205,   326,   270,   271,
       1,   337,    80,   216,   217,     2,     3,   218,   219,   220,
       4,    82,     5,     6,     7,   221,   222,   223,     8,     9,
      10,   224,    11,    12,   118,    13,    14,   225,    91,    92,
      15,    16,    17,   226,   119,   120,   121,   122,   123,    93,
      96,   100,   102,   105,   155,   110,   205,   162,   156,   124,
     125,   205,   126,   175,   127,   128,   192,   193,   194,   195,
     196,   197,   198,   199,   200,   201,   129,   130,   314,   313,
     176,   245,   227,   177,   202,   178,   131,   132,     1,   156,
     228,   216,   217,     2,     3,   218,   219,   220,     4,   215,
       5,     6,     7,   221,   222,   223,     8,     9,    10,   224,
      11,    12,   118,    13,    14,   225,   246,   280,    15,    16,
      17,   226,   119,   120,   121,   122,   123,   281,   283,   285,
     288,   286,   289,   298,   310,   299,   290,   124,   125,   293,
     126,   294,   127,   128,   300,   301,   312,   317,   328,   331,
     322,   323,   342,   252,   129,   130,    75,   343,   344,    47,
     227,    98,   347,   247,   131,   132,     1,   156,   295,   153,
      85,     2,     3,    88,    81,   103,     4,   345,    52,     6,
       7,   258,   257,   261,     8,     9,    10,   260,    11,    12,
       0,    13,    53,     0,     1,   259,    15,    16,    17,     2,
       3,     0,     0,     0,     4,     0,    52,     6,     7,     0,
       0,     0,     8,     9,    10,     0,    11,    12,     0,    13,
      53,     0,     0,     0,    15,    16,    17,     0,     0,     0,
       0,     0,     0,     0,     0,     1,     0,     0,   216,   217,
       2,     3,   218,   219,   220,     4,    89,     5,     6,     7,
     221,   222,   223,     8,     9,    10,   224,    11,    12,   118,
      13,    14,   225,     0,     0,    15,    16,    17,   226,   119,
     120,   121,   122,   123,   104,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   124,   125,     0,   126,     0,   127,
     128,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   129,   130,     1,     0,     0,     0,   227,     2,     3,
       0,   131,   132,     4,   156,    52,     6,     7,     0,     0,
       0,     8,     9,    10,     0,    11,    12,     0,    13,    53,
       0,     1,     0,    15,    16,    17,     2,     3,     0,     0,
       0,     4,     0,    52,     6,     7,     0,     0,     0,     8,
       9,    10,     0,    11,    12,     0,    13,    53,     0,     0,
       0,    15,    16,    17,     1,     0,     0,     0,     0,     2,
       3,     0,     0,     0,     4,     0,    52,     6,     7,     0,
       0,   111,     8,     9,    10,     0,    11,    12,   118,    13,
      53,     0,     0,     0,    15,    16,    17,     0,   119,   120,
     121,   122,   123,     0,     0,     0,     0,     0,     0,   152,
       0,     0,     0,   124,   125,     0,   126,     0,   127,   128,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     129,   130,     1,     0,     0,     0,     0,     2,     3,     0,
     131,   132,     4,     0,     5,     6,     7,     0,     0,     0,
       8,     9,    10,     0,    11,    12,     0,    13,    14,     0,
       2,     0,    15,    16,    17,     4,     0,    52,     0,     7,
       0,     0,     0,     8,     9,     0,     0,    11,    12,   118,
       0,    53,     0,     0,     0,    15,    16,   118,     0,   119,
     120,   121,   122,   123,     0,     0,     0,   119,   120,   121,
     122,   123,     0,     0,   124,   125,    18,   126,     0,   127,
     128,     0,   124,   125,     0,   126,     0,   127,   128,     0,
       0,   129,   130,   118,     0,     0,     0,     0,     0,   129,
     130,   131,   132,   119,   120,   121,   122,   123,     0,   131,
     132,     0,   133,   304,     0,     0,     0,     0,   124,   125,
       0,   126,     0,   127,   128,     0,     0,   118,     0,     0,
       0,     0,     0,     0,     0,   129,   130,   119,   120,   121,
     122,   123,     0,     0,     0,   131,   132,     0,   133,     0,
       0,     0,   124,   125,     0,   126,     0,   127,   128,     0,
       0,   118,     0,     0,     0,     0,     0,     0,     0,   129,
     130,   119,   120,   121,   122,   123,     0,     0,     0,   131,
     132,   276,     0,     0,     0,     0,   124,   125,     0,   126,
       0,   127,   128,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   129,   130,   118,     0,     0,     0,   291,
       0,     0,   118,   131,   132,   119,   120,   121,   122,   123,
       0,     0,   119,   120,   121,   122,   123,     0,     0,     0,
     124,   125,     0,   126,     0,   127,   128,   124,   125,     0,
     126,     0,   127,   128,     0,     0,     0,   129,   130,   118,
       0,     0,     0,     0,   129,   130,     0,   131,   163,   119,
     120,   121,   122,   123,   131,   165,     0,     0,     0,     0,
       0,     0,     0,     0,   124,   125,     0,   126,     0,   127,
     128,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   129,   130,     1,     0,     0,     0,     0,     2,     3,
       0,   131,   132,     4,     0,    52,     6,     7,     0,     0,
       0,     8,     9,    10,     0,    11,    12,     0,    13,    53,
       0,     0,     0,    15,    16,    17
};

static const yytype_int16 yycheck[] =
{
       0,     0,   133,   220,    86,   149,    96,   111,   217,    38,
      37,   132,    58,    37,     0,    41,     8,    66,   235,    22,
      20,    20,    26,    78,    54,    78,    26,    75,    83,    21,
      22,    75,    85,    25,    20,    81,    85,    63,    68,    39,
      39,     0,   163,   133,   165,   189,   190,   191,   152,    80,
      54,    84,   173,    84,    54,    82,    85,   161,    82,    56,
      78,    58,    59,    63,    63,    83,    66,    66,    78,   286,
       4,     5,   154,    83,    61,    62,    52,    53,    78,    63,
      64,    65,    66,   118,    75,    85,    85,    78,   209,   124,
     125,    73,    74,   310,    94,    94,    25,   306,    27,    82,
     100,   100,    75,   224,    80,    78,    58,   251,    84,   213,
      86,    87,    37,   203,   149,   332,   333,   334,   208,    75,
       8,    78,    78,   254,    81,    78,   343,    55,    81,    57,
     347,    82,   132,    21,    22,    64,    65,    25,    37,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   186,   187,   188,   189,   190,   191,   301,   313,   314,
     160,   160,   252,   163,   254,    78,    58,   288,    81,   290,
     179,   180,   293,   294,   181,   182,   183,   184,    75,   108,
       8,    78,   217,   112,   113,    13,    37,    15,    78,    17,
      37,    81,    75,    21,    22,    78,    78,    25,    26,    81,
      78,    29,    76,    81,    78,    33,    34,   328,    78,    78,
     331,    81,    81,   185,   186,    37,   251,   307,   187,   188,
       3,   342,    37,     6,     7,     8,     9,    10,    11,    12,
      13,    60,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    28,    29,    30,    38,    37,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    58,
      60,    80,    38,    37,    37,    86,   301,    85,    82,    52,
      53,   306,    55,    67,    57,    58,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    69,    70,   288,   288,
      71,    37,    75,    72,    60,    70,    79,    80,     3,    82,
      83,     6,     7,     8,     9,    10,    11,    12,    13,    64,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    37,    37,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    37,    75,    75,
      80,    76,    37,    84,    76,    84,    80,    52,    53,    80,
      55,    80,    57,    58,    81,    81,    36,    75,    80,    75,
      85,    85,    75,    78,    69,    70,    78,    14,    75,    20,
      75,    75,    81,   160,    79,    80,     3,    82,    83,   100,
      63,     8,     9,    65,    59,    83,    13,   342,    15,    16,
      17,   175,   174,   178,    21,    22,    23,   177,    25,    26,
      -1,    28,    29,    -1,     3,   176,    33,    34,    35,     8,
       9,    -1,    -1,    -1,    13,    -1,    15,    16,    17,    -1,
      -1,    -1,    21,    22,    23,    -1,    25,    26,    -1,    28,
      29,    -1,    -1,    -1,    33,    34,    35,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,     3,    -1,    -1,     6,     7,
       8,     9,    10,    11,    12,    13,    83,    15,    16,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      28,    29,    30,    -1,    -1,    33,    34,    35,    36,    37,
      38,    39,    40,    41,    83,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    52,    53,    -1,    55,    -1,    57,
      58,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    69,    70,     3,    -1,    -1,    -1,    75,     8,     9,
      -1,    79,    80,    13,    82,    15,    16,    17,    -1,    -1,
      -1,    21,    22,    23,    -1,    25,    26,    -1,    28,    29,
      -1,     3,    -1,    33,    34,    35,     8,     9,    -1,    -1,
      -1,    13,    -1,    15,    16,    17,    -1,    -1,    -1,    21,
      22,    23,    -1,    25,    26,    -1,    28,    29,    -1,    -1,
      -1,    33,    34,    35,     3,    -1,    -1,    -1,    -1,     8,
       9,    -1,    -1,    -1,    13,    -1,    15,    16,    17,    -1,
      -1,    81,    21,    22,    23,    -1,    25,    26,    27,    28,
      29,    -1,    -1,    -1,    33,    34,    35,    -1,    37,    38,
      39,    40,    41,    -1,    -1,    -1,    -1,    -1,    -1,    81,
      -1,    -1,    -1,    52,    53,    -1,    55,    -1,    57,    58,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      69,    70,     3,    -1,    -1,    -1,    -1,     8,     9,    -1,
      79,    80,    13,    -1,    15,    16,    17,    -1,    -1,    -1,
      21,    22,    23,    -1,    25,    26,    -1,    28,    29,    -1,
       8,    -1,    33,    34,    35,    13,    -1,    15,    -1,    17,
      -1,    -1,    -1,    21,    22,    -1,    -1,    25,    26,    27,
      -1,    29,    -1,    -1,    -1,    33,    34,    27,    -1,    37,
      38,    39,    40,    41,    -1,    -1,    -1,    37,    38,    39,
      40,    41,    -1,    -1,    52,    53,    77,    55,    -1,    57,
      58,    -1,    52,    53,    -1,    55,    -1,    57,    58,    -1,
      -1,    69,    70,    27,    -1,    -1,    -1,    -1,    -1,    69,
      70,    79,    80,    37,    38,    39,    40,    41,    -1,    79,
      80,    -1,    82,    83,    -1,    -1,    -1,    -1,    52,    53,
      -1,    55,    -1,    57,    58,    -1,    -1,    27,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    69,    70,    37,    38,    39,
      40,    41,    -1,    -1,    -1,    79,    80,    -1,    82,    -1,
      -1,    -1,    52,    53,    -1,    55,    -1,    57,    58,    -1,
      -1,    27,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    69,
      70,    37,    38,    39,    40,    41,    -1,    -1,    -1,    79,
      80,    81,    -1,    -1,    -1,    -1,    52,    53,    -1,    55,
      -1,    57,    58,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    69,    70,    27,    -1,    -1,    -1,    75,
      -1,    -1,    27,    79,    80,    37,    38,    39,    40,    41,
      -1,    -1,    37,    38,    39,    40,    41,    -1,    -1,    -1,
      52,    53,    -1,    55,    -1,    57,    58,    52,    53,    -1,
      55,    -1,    57,    58,    -1,    -1,    -1,    69,    70,    27,
      -1,    -1,    -1,    -1,    69,    70,    -1,    79,    80,    37,
      38,    39,    40,    41,    79,    80,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    52,    53,    -1,    55,    -1,    57,
      58,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    69,    70,     3,    -1,    -1,    -1,    -1,     8,     9,
      -1,    79,    80,    13,    -1,    15,    16,    17,    -1,    -1,
      -1,    21,    22,    23,    -1,    25,    26,    -1,    28,    29,
      -1,    -1,    -1,    33,    34,    35
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     3,     8,     9,    13,    15,    16,    17,    21,    22,
      23,    25,    26,    28,    29,    33,    34,    35,    77,    91,
      92,    93,    94,    95,    96,    97,    98,    99,   106,   109,
     113,    37,    82,    22,     8,    21,    22,    25,    37,    82,
       8,    21,    22,    25,     4,     5,     0,    93,    58,   100,
     101,   102,    15,    29,    98,    99,   100,    75,    75,    82,
      37,   114,   115,    82,    97,    99,   110,   111,    37,    41,
      63,    58,    37,   103,    75,    78,    37,    37,    98,    99,
      37,   114,    60,    78,    83,   110,   100,   112,   112,    83,
     111,    38,    37,    58,    80,    84,    60,   100,   102,    99,
      80,    83,    38,   115,    83,    37,   103,    75,    78,    75,
      86,    81,    97,    99,   107,   108,    38,    85,    27,    37,
      38,    39,    40,    41,    52,    53,    55,    57,    58,    69,
      70,    79,    80,    82,   104,   131,   133,   134,   135,   136,
     137,   138,   139,   140,   141,   142,   143,   144,   145,   146,
     147,   149,    81,   107,   100,    37,    82,   118,   100,   100,
      78,    81,    85,    80,   145,    80,   145,   145,    99,   130,
     131,   104,   105,    54,    68,    67,    71,    72,    70,    61,
      62,    63,    64,    65,    66,    73,    74,    55,    57,    56,
      58,    59,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    60,   132,   144,   145,    52,    53,    80,    84,
      86,    87,   118,    81,   103,    64,     6,     7,    10,    11,
      12,    18,    19,    20,    24,    30,    36,    75,    83,    96,
      97,    99,   116,   117,   118,   119,   120,   121,   122,   123,
     124,   127,   128,   129,   130,    37,    37,   108,   118,    99,
      58,    81,    78,    81,    78,    83,   130,   135,   136,   137,
     138,   139,   140,   140,   141,   141,   141,   141,   142,   142,
     143,   143,   144,   144,   144,   131,    81,   131,   148,   130,
      37,    37,   118,    75,   133,    75,    76,   116,    80,    37,
      80,    75,   130,    80,    80,    83,   116,    75,    84,    84,
      81,    81,   144,   131,    83,   104,    76,    78,    81,    85,
      76,   116,    36,    97,    99,   125,   130,    75,   130,    75,
     130,   130,    85,    85,   144,   133,   131,   116,    80,   101,
     101,    75,    81,    81,    81,   130,   126,   130,   116,   116,
     116,    81,    75,    14,    75,   126,   116,    81,   116
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_uint8 yyr1[] =
{
       0,    90,    91,    91,    92,    92,    93,    93,    94,    94,
      94,    94,    95,    95,    96,    96,    96,    97,    97,    97,
      97,    98,    98,    98,    98,    98,    98,    99,    99,    99,
      99,    99,    99,    99,    99,    99,    99,    99,    99,    99,
      99,    99,    99,    99,    99,    99,    99,   100,   100,   100,
     100,   101,   101,   102,   102,   103,   103,   103,   104,   104,
     104,   105,   105,   106,   106,   106,   106,   107,   107,   108,
     108,   108,   108,   108,   108,   109,   109,   110,   110,   111,
     111,   112,   112,   113,   113,   114,   114,   115,   115,   116,
     116,   116,   116,   116,   116,   116,   116,   116,   116,   116,
     117,   117,   118,   118,   119,   119,   120,   120,   121,   122,
     123,   124,   125,   125,   125,   125,   126,   126,   127,   127,
     127,   127,   127,   128,   128,   129,   129,   130,   130,   131,
     131,   132,   132,   132,   132,   132,   132,   132,   132,   132,
     132,   132,   133,   133,   134,   134,   135,   135,   136,   136,
     137,   137,   138,   138,   139,   139,   139,   140,   140,   140,
     140,   140,   141,   141,   141,   142,   142,   142,   143,   143,
     143,   143,   144,   144,   144,   145,   145,   145,   145,   145,
     145,   146,   146,   146,   146,   146,   146,   147,   147,   147,
     147,   147,   147,   147,   147,   148,   148,   149,   149,   149,
     149,   149,   149
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     0,     1,     1,     2,     1,     1,     3,     7,
       3,     4,     1,     1,     3,     2,     2,     1,     2,     3,
       4,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     0,     1,     2,
       3,     1,     3,     2,     4,     1,     4,     3,     1,     3,
       4,     1,     3,     7,     6,     7,     6,     1,     3,     3,
       5,     2,     3,     5,     2,     5,     4,     1,     2,     3,
       3,     2,     4,     5,     4,     1,     3,     1,     3,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     2,     3,     1,     2,     5,     7,     5,     5,
       7,     9,     0,     1,     2,     2,     0,     1,     3,     2,
       2,     2,     3,     3,     4,     2,     3,     1,     3,     1,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     5,     1,     3,     1,     3,     1,     3,
       1,     3,     1,     3,     1,     3,     3,     1,     3,     3,
       3,     3,     1,     3,     3,     1,     3,     3,     1,     3,
       3,     3,     1,     4,     5,     1,     2,     2,     2,     2,
       4,     1,     1,     1,     1,     1,     1,     1,     4,     3,
       4,     3,     3,     2,     2,     1,     3,     1,     1,     1,
       1,     1,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]));
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


/* Context of a parse error.  */
typedef struct
{
  yy_state_t *yyssp;
  yysymbol_kind_t yytoken;
  YYLTYPE *yylloc;
} yypcontext_t;

/* Put in YYARG at most YYARGN of the expected tokens given the
   current YYCTX, and return the number of tokens stored in YYARG.  If
   YYARG is null, return the number of expected tokens (guaranteed to
   be less than YYNTOKENS).  Return YYENOMEM on memory exhaustion.
   Return 0 if there are more than YYARGN expected tokens, yet fill
   YYARG up to YYARGN. */
static int
yypcontext_expected_tokens (const yypcontext_t *yyctx,
                            yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  int yyn = yypact[+*yyctx->yyssp];
  if (!yypact_value_is_default (yyn))
    {
      /* Start YYX at -YYN if negative to avoid negative indexes in
         YYCHECK.  In other words, skip the first -YYN actions for
         this state because they are default actions.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;
      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yyx;
      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
        if (yycheck[yyx + yyn] == yyx && yyx != YYSYMBOL_YYerror
            && !yytable_value_is_error (yytable[yyx + yyn]))
          {
            if (!yyarg)
              ++yycount;
            else if (yycount == yyargn)
              return 0;
            else
              yyarg[yycount++] = YY_CAST (yysymbol_kind_t, yyx);
          }
    }
  if (yyarg && yycount == 0 && 0 < yyargn)
    yyarg[0] = YYSYMBOL_YYEMPTY;
  return yycount;
}




#ifndef yystrlen
# if defined __GLIBC__ && defined _STRING_H
#  define yystrlen(S) (YY_CAST (YYPTRDIFF_T, strlen (S)))
# else
/* Return the length of YYSTR.  */
static YYPTRDIFF_T
yystrlen (const char *yystr)
{
  YYPTRDIFF_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
# endif
#endif

#ifndef yystpcpy
# if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#  define yystpcpy stpcpy
# else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
# endif
#endif

#ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYPTRDIFF_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYPTRDIFF_T yyn = 0;
      char const *yyp = yystr;
      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            else
              goto append;

          append:
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (yyres)
    return yystpcpy (yyres, yystr) - yyres;
  else
    return yystrlen (yystr);
}
#endif


static int
yy_syntax_error_arguments (const yypcontext_t *yyctx,
                           yysymbol_kind_t yyarg[], int yyargn)
{
  /* Actual size of YYARG. */
  int yycount = 0;
  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yyctx->yytoken != YYSYMBOL_YYEMPTY)
    {
      int yyn;
      if (yyarg)
        yyarg[yycount] = yyctx->yytoken;
      ++yycount;
      yyn = yypcontext_expected_tokens (yyctx,
                                        yyarg ? yyarg + 1 : yyarg, yyargn - 1);
      if (yyn == YYENOMEM)
        return YYENOMEM;
      else
        yycount += yyn;
    }
  return yycount;
}

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return -1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return YYENOMEM if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYPTRDIFF_T *yymsg_alloc, char **yymsg,
                const yypcontext_t *yyctx)
{
  enum { YYARGS_MAX = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat: reported tokens (one for the "unexpected",
     one per "expected"). */
  yysymbol_kind_t yyarg[YYARGS_MAX];
  /* Cumulated lengths of YYARG.  */
  YYPTRDIFF_T yysize = 0;

  /* Actual size of YYARG. */
  int yycount = yy_syntax_error_arguments (yyctx, yyarg, YYARGS_MAX);
  if (yycount == YYENOMEM)
    return YYENOMEM;

  switch (yycount)
    {
#define YYCASE_(N, S)                       \
      case N:                               \
        yyformat = S;                       \
        break
    default: /* Avoid compiler warnings. */
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
#undef YYCASE_
    }

  /* Compute error message size.  Don't count the "%s"s, but reserve
     room for the terminator.  */
  yysize = yystrlen (yyformat) - 2 * yycount + 1;
  {
    int yyi;
    for (yyi = 0; yyi < yycount; ++yyi)
      {
        YYPTRDIFF_T yysize1
          = yysize + yytnamerr (YY_NULLPTR, yytname[yyarg[yyi]]);
        if (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM)
          yysize = yysize1;
        else
          return YYENOMEM;
      }
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return -1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yytname[yyarg[yyi++]]);
          yyformat += 2;
        }
      else
        {
          ++yyp;
          ++yyformat;
        }
  }
  return 0;
}


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Location data for the lookahead symbol.  */
YYLTYPE yylloc
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];

  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYPTRDIFF_T yymsg_alloc = sizeof yymsgbuf;

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {

#line 2007 "parser.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      {
        yypcontext_t yyctx
          = {yyssp, yytoken, &yylloc};
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == -1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = YY_CAST (char *,
                             YYSTACK_ALLOC (YY_CAST (YYSIZE_T, yymsg_alloc)));
            if (yymsg)
              {
                yysyntax_error_status
                  = yysyntax_error (&yymsg_alloc, &yymsg, &yyctx);
                yymsgp = yymsg;
              }
            else
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = YYENOMEM;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == YYENOMEM)
          YYNOMEM;
      }
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
  return yyresult;
}

#line 509 "parser.y"


/* ======================
   FUNCIÓN DE ERROR
   ====================== */
void read_line_from_file(int line_num, char *buffer, size_t size) {
    if (!filename) {
        buffer[0] = '\0';
        return;
    }
    
    FILE *f = fopen(filename, "r");
    if (!f) {
        buffer[0] = '\0';
        return;
    }
    
    int current = 1;
    while (fgets(buffer, size, f)) {
        if (current == line_num) {
            size_t len = strlen(buffer);
            if (len > 0 && buffer[len-1] == '\n') {
                buffer[len-1] = '\0';
            }
            if (len > 1 && buffer[len-2] == '\r') {
                buffer[len-2] = '\0';
            }
            fclose(f);
            return;
        }
        current++;
    }
    fclose(f);
    buffer[0] = '\0';
}

const char* token_to_symbol(const char* token_name) {
    if (strstr(token_name, "TOKEN_PUNTO_COMA")) return "';'";
    if (strstr(token_name, "TOKEN_DOS_PUNTO")) return "':'";
    if (strstr(token_name, "TOKEN_COMA")) return "','";
    if (strstr(token_name, "TOKEN_PUNTO")) return "'.'";
    if (strstr(token_name, "TOKEN_GATO")) return "'#'";
    if (strstr(token_name, "TOKEN_TILDE")) return "'~'";
    
    if (strstr(token_name, "TOKEN_PARENT_IZQ")) return "'('";
    if (strstr(token_name, "TOKEN_PARENT_DER")) return "')'";
    if (strstr(token_name, "TOKEN_LLAVE_IZQ")) return "'{'";
    if (strstr(token_name, "TOKEN_LLAVE_DER")) return "'}'";
    if (strstr(token_name, "TOKEN_CORCH_IZQ")) return "'['";
    if (strstr(token_name, "TOKEN_CORCH_DER")) return "']'";
    
    if (strstr(token_name, "TOKEN_ADD_ASSIGN")) return "'+='";
    if (strstr(token_name, "TOKEN_SUB_ASSIGN")) return "'-='";
    if (strstr(token_name, "TOKEN_MUL_ASSIGN")) return "'*='";
    if (strstr(token_name, "TOKEN_DIV_ASSIGN")) return "'/='";
    if (strstr(token_name, "TOKEN_MOD_ASSIGN")) return "'%='";
    if (strstr(token_name, "TOKEN_SHL_ASSIGN")) return "'<<='";
    if (strstr(token_name, "TOKEN_SHR_ASSIGN")) return "'>>='";
    if (strstr(token_name, "TOKEN_AND_ASSIGN")) return "'&='";
    if (strstr(token_name, "TOKEN_XOR_ASSIGN")) return "'^='";
    if (strstr(token_name, "TOKEN_OR_ASSIGN")) return "'|='";
    
    if (strstr(token_name, "TOKEN_INC")) return "'++'";
    if (strstr(token_name, "TOKEN_DEC")) return "'--'";
    if (strstr(token_name, "TOKEN_FLECHA")) return "'->'";
    if (strstr(token_name, "TOKEN_TERN_IF")) return "'?'";
    if (strstr(token_name, "TOKEN_MAS")) return "'+'";
    if (strstr(token_name, "TOKEN_MENOS")) return "'-'";
    if (strstr(token_name, "TOKEN_MULT")) return "'*'";
    if (strstr(token_name, "TOKEN_DIV")) return "'/'";
    if (strstr(token_name, "TOKEN_MOD")) return "'%'";
    if (strstr(token_name, "TOKEN_ASIGN")) return "'='";
    
    if (strstr(token_name, "TOKEN_IGUAL")) return "'=='";
    if (strstr(token_name, "TOKEN_DIF")) return "'!='";
    if (strstr(token_name, "TOKEN_MENOR_IGUAL")) return "'<='";
    if (strstr(token_name, "TOKEN_MAYOR_IGUAL")) return "'>='";
    if (strstr(token_name, "TOKEN_MENOR")) return "'<'";
    if (strstr(token_name, "TOKEN_MAYOR")) return "'>'";
    
    if (strstr(token_name, "TOKEN_AND")) return "'&&'";
    if (strstr(token_name, "TOKEN_OR")) return "'||'";
    if (strstr(token_name, "TOKEN_NOT")) return "'!'";
    if (strstr(token_name, "TOKEN_AND_BIT")) return "'&'";
    if (strstr(token_name, "TOKEN_OR_BIT")) return "'|'";
    if (strstr(token_name, "TOKEN_XOR")) return "'^'";
    if (strstr(token_name, "TOKEN_DESPL_IZQ")) return "'<<'";
    if (strstr(token_name, "TOKEN_DESPL_DER")) return "'>>'";
    
    if (strstr(token_name, "TOKEN_AUTO")) return "'auto'";
    if (strstr(token_name, "TOKEN_BREAK")) return "'break'";
    if (strstr(token_name, "TOKEN_CASE")) return "'case'";
    if (strstr(token_name, "TOKEN_CHAR")) return "'char'";
    if (strstr(token_name, "TOKEN_CONST")) return "'const'";
    if (strstr(token_name, "TOKEN_CONTINUE")) return "'continue'";
    if (strstr(token_name, "TOKEN_DEFAULT")) return "'default'";
    if (strstr(token_name, "TOKEN_DEFINE")) return "'define'";
    if (strstr(token_name, "TOKEN_DO")) return "'do'";
    if (strstr(token_name, "TOKEN_DOUBLE")) return "'double'";
    if (strstr(token_name, "TOKEN_ELSE")) return "'else'";
    if (strstr(token_name, "TOKEN_ENUM")) return "'enum'";
    if (strstr(token_name, "TOKEN_EXTERN")) return "'extern'";
    if (strstr(token_name, "TOKEN_FLOAT")) return "'float'";
    if (strstr(token_name, "TOKEN_FOR")) return "'for'";
    if (strstr(token_name, "TOKEN_GOTO")) return "'goto'";
    if (strstr(token_name, "TOKEN_IF")) return "'if'";
    if (strstr(token_name, "TOKEN_INCLUDE")) return "'include'";
    if (strstr(token_name, "TOKEN_INT")) return "'int'";
    if (strstr(token_name, "TOKEN_LONG")) return "'long'";
    if (strstr(token_name, "TOKEN_REGISTER")) return "'register'";
    if (strstr(token_name, "TOKEN_RETURN")) return "'return'";
    if (strstr(token_name, "TOKEN_SHORT")) return "'short'";
    if (strstr(token_name, "TOKEN_SIGNED")) return "'signed'";
    if (strstr(token_name, "TOKEN_SIZEOF")) return "'sizeof'";
    if (strstr(token_name, "TOKEN_STATIC")) return "'static'";
    if (strstr(token_name, "TOKEN_STRUCT")) return "'struct'";
    if (strstr(token_name, "TOKEN_SWITCH")) return "'switch'";
    if (strstr(token_name, "TOKEN_TYPEDEF")) return "'typedef'";
    if (strstr(token_name, "TOKEN_UNION")) return "'union'";
    if (strstr(token_name, "TOKEN_UNSIGNED")) return "'unsigned'";
    if (strstr(token_name, "TOKEN_VOID")) return "'void'";
    if (strstr(token_name, "TOKEN_VOLATILE")) return "'volatile'";
    if (strstr(token_name, "TOKEN_WHILE")) return "'while'";
    
    if (strstr(token_name, "TOKEN_ID")) return "identifier";
    if (strstr(token_name, "TOKEN_CONST_ENTERO")) return "integer constant";
    if (strstr(token_name, "TOKEN_CONST_FLOTANTE")) return "floating constant";
    if (strstr(token_name, "TOKEN_CONST_CARACTER")) return "character constant";
    if (strstr(token_name, "TOKEN_CONST_CADENA")) return "string literal";
    if (strstr(token_name, "TOKEN_ERROR")) return "invalid token";
    
    return token_name;
}

char* replace_tokens_in_message(const char* original) {
    static char result[1024];
    const char *pos = original;
    result[0] = '\0';
    char buffer[1024];
    int buf_idx = 0;
    
    while (*pos) {
        if (strncmp(pos, "TOKEN_", 6) == 0) {
            const char *token_start = pos;
            pos += 6;
            
            char token_name[128] = "TOKEN_";
            int i = 6;
            while (*pos && (isalnum(*pos) || *pos == '_')) {
                token_name[i++] = *pos++;
            }
            token_name[i] = '\0';
            
            buffer[buf_idx] = '\0';
            strcat(result, buffer);
            buf_idx = 0;
            
            strcat(result, token_to_symbol(token_name));
        } else {
            buffer[buf_idx++] = *pos++;
        }
    }
    
    buffer[buf_idx] = '\0';
    strcat(result, buffer);
    
    return result;
}

void yyerror(const char *s) {
    char line_content[1024];
    read_line_from_file(yylloc.first_line, line_content, sizeof(line_content));
    
    char *clean_message = replace_tokens_in_message(s);
    
    fprintf(stderr, "%s:%d:%d: error: %s\n",
            filename ? filename : "input",
            yylloc.first_line,
            yylloc.first_column,
            clean_message);
    
    if (line_content[0] != '\0') {
        fprintf(stderr, " %s\n", line_content);
        
        fprintf(stderr, " ");
        for (int i = 1; i < yylloc.first_column; i++) {
            fprintf(stderr, " ");
        }
        fprintf(stderr, "^\n");
    }
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Uso: %s <archivo.c>\n", argv[0]);
        return 1;
    }

    filename = argv[1];
    
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("❌ Error: no se puede abrir el archivo '%s'\n", filename);
        return 1;
    }

    yyin = file;

    printf("Compilador COMPI Iniciado...\n");

    int result = yyparse();

    if (result == 0)
        printf("✔ Código válido\n");
    else
        printf("✖ Código inválido\n");

    fclose(file);
    return result;
}
