/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_PARSER_TAB_H_INCLUDED
# define YY_YY_PARSER_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    TOKEN_AUTO = 258,              /* TOKEN_AUTO  */
    TOKEN_DEFINE = 259,            /* TOKEN_DEFINE  */
    TOKEN_INCLUDE = 260,           /* TOKEN_INCLUDE  */
    TOKEN_BREAK = 261,             /* TOKEN_BREAK  */
    TOKEN_CASE = 262,              /* TOKEN_CASE  */
    TOKEN_CHAR = 263,              /* TOKEN_CHAR  */
    TOKEN_CONST = 264,             /* TOKEN_CONST  */
    TOKEN_CONTINUE = 265,          /* TOKEN_CONTINUE  */
    TOKEN_DEFAULT = 266,           /* TOKEN_DEFAULT  */
    TOKEN_DO = 267,                /* TOKEN_DO  */
    TOKEN_DOUBLE = 268,            /* TOKEN_DOUBLE  */
    TOKEN_ELSE = 269,              /* TOKEN_ELSE  */
    TOKEN_ENUM = 270,              /* TOKEN_ENUM  */
    TOKEN_EXTERN = 271,            /* TOKEN_EXTERN  */
    TOKEN_FLOAT = 272,             /* TOKEN_FLOAT  */
    TOKEN_FOR = 273,               /* TOKEN_FOR  */
    TOKEN_GOTO = 274,              /* TOKEN_GOTO  */
    TOKEN_IF = 275,                /* TOKEN_IF  */
    TOKEN_INT = 276,               /* TOKEN_INT  */
    TOKEN_LONG = 277,              /* TOKEN_LONG  */
    TOKEN_REGISTER = 278,          /* TOKEN_REGISTER  */
    TOKEN_RETURN = 279,            /* TOKEN_RETURN  */
    TOKEN_SHORT = 280,             /* TOKEN_SHORT  */
    TOKEN_SIGNED = 281,            /* TOKEN_SIGNED  */
    TOKEN_SIZEOF = 282,            /* TOKEN_SIZEOF  */
    TOKEN_STATIC = 283,            /* TOKEN_STATIC  */
    TOKEN_STRUCT = 284,            /* TOKEN_STRUCT  */
    TOKEN_SWITCH = 285,            /* TOKEN_SWITCH  */
    TOKEN_TYPEDEF = 286,           /* TOKEN_TYPEDEF  */
    TOKEN_UNION = 287,             /* TOKEN_UNION  */
    TOKEN_UNSIGNED = 288,          /* TOKEN_UNSIGNED  */
    TOKEN_VOID = 289,              /* TOKEN_VOID  */
    TOKEN_VOLATILE = 290,          /* TOKEN_VOLATILE  */
    TOKEN_WHILE = 291,             /* TOKEN_WHILE  */
    TOKEN_ID = 292,                /* TOKEN_ID  */
    TOKEN_CONST_ENTERO = 293,      /* TOKEN_CONST_ENTERO  */
    TOKEN_CONST_FLOTANTE = 294,    /* TOKEN_CONST_FLOTANTE  */
    TOKEN_CONST_CARACTER = 295,    /* TOKEN_CONST_CARACTER  */
    TOKEN_CONST_CADENA = 296,      /* TOKEN_CONST_CADENA  */
    TOKEN_ADD_ASSIGN = 297,        /* TOKEN_ADD_ASSIGN  */
    TOKEN_SUB_ASSIGN = 298,        /* TOKEN_SUB_ASSIGN  */
    TOKEN_MUL_ASSIGN = 299,        /* TOKEN_MUL_ASSIGN  */
    TOKEN_DIV_ASSIGN = 300,        /* TOKEN_DIV_ASSIGN  */
    TOKEN_MOD_ASSIGN = 301,        /* TOKEN_MOD_ASSIGN  */
    TOKEN_SHL_ASSIGN = 302,        /* TOKEN_SHL_ASSIGN  */
    TOKEN_SHR_ASSIGN = 303,        /* TOKEN_SHR_ASSIGN  */
    TOKEN_AND_ASSIGN = 304,        /* TOKEN_AND_ASSIGN  */
    TOKEN_XOR_ASSIGN = 305,        /* TOKEN_XOR_ASSIGN  */
    TOKEN_OR_ASSIGN = 306,         /* TOKEN_OR_ASSIGN  */
    TOKEN_INC = 307,               /* TOKEN_INC  */
    TOKEN_DEC = 308,               /* TOKEN_DEC  */
    TOKEN_TERN_IF = 309,           /* TOKEN_TERN_IF  */
    TOKEN_MAS = 310,               /* TOKEN_MAS  */
    TOKEN_MOD = 311,               /* TOKEN_MOD  */
    TOKEN_MENOS = 312,             /* TOKEN_MENOS  */
    TOKEN_MULT = 313,              /* TOKEN_MULT  */
    TOKEN_DIV = 314,               /* TOKEN_DIV  */
    TOKEN_ASIGN = 315,             /* TOKEN_ASIGN  */
    TOKEN_IGUAL = 316,             /* TOKEN_IGUAL  */
    TOKEN_DIF = 317,               /* TOKEN_DIF  */
    TOKEN_MENOR = 318,             /* TOKEN_MENOR  */
    TOKEN_MAYOR = 319,             /* TOKEN_MAYOR  */
    TOKEN_MENOR_IGUAL = 320,       /* TOKEN_MENOR_IGUAL  */
    TOKEN_MAYOR_IGUAL = 321,       /* TOKEN_MAYOR_IGUAL  */
    TOKEN_AND = 322,               /* TOKEN_AND  */
    TOKEN_OR = 323,                /* TOKEN_OR  */
    TOKEN_NOT = 324,               /* TOKEN_NOT  */
    TOKEN_AND_BIT = 325,           /* TOKEN_AND_BIT  */
    TOKEN_OR_BIT = 326,            /* TOKEN_OR_BIT  */
    TOKEN_XOR = 327,               /* TOKEN_XOR  */
    TOKEN_DESPL_IZQ = 328,         /* TOKEN_DESPL_IZQ  */
    TOKEN_DESPL_DER = 329,         /* TOKEN_DESPL_DER  */
    TOKEN_PUNTO_COMA = 330,        /* TOKEN_PUNTO_COMA  */
    TOKEN_DOS_PUNTO = 331,         /* TOKEN_DOS_PUNTO  */
    TOKEN_GATO = 332,              /* TOKEN_GATO  */
    TOKEN_COMA = 333,              /* TOKEN_COMA  */
    TOKEN_TILDE = 334,             /* TOKEN_TILDE  */
    TOKEN_PARENT_IZQ = 335,        /* TOKEN_PARENT_IZQ  */
    TOKEN_PARENT_DER = 336,        /* TOKEN_PARENT_DER  */
    TOKEN_LLAVE_IZQ = 337,         /* TOKEN_LLAVE_IZQ  */
    TOKEN_LLAVE_DER = 338,         /* TOKEN_LLAVE_DER  */
    TOKEN_CORCH_IZQ = 339,         /* TOKEN_CORCH_IZQ  */
    TOKEN_CORCH_DER = 340,         /* TOKEN_CORCH_DER  */
    TOKEN_PUNTO = 341,             /* TOKEN_PUNTO  */
    TOKEN_FLECHA = 342,            /* TOKEN_FLECHA  */
    TOKEN_ERROR = 343,             /* TOKEN_ERROR  */
    LOWER_THAN_ELSE = 344          /* LOWER_THAN_ELSE  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 25 "parser.y"

    char* id;
    int entero;
    float real;
    char caracter;
    char* cadena;

#line 161 "parser.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


extern YYSTYPE yylval;
extern YYLTYPE yylloc;

int yyparse (void);


#endif /* !YY_YY_PARSER_TAB_H_INCLUDED  */
