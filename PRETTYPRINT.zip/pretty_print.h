#ifndef PRETTY_PRINT_H
#define PRETTY_PRINT_H

void formatear_codigo(const char* archivo_entrada, const char* archivo_salida, int estilo);

#endif