#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

void escape_latex_string(FILE* output, const char* input) {
    if (!input) return;
    
    for (size_t i = 0; i < strlen(input); i++) {
        unsigned char c = input[i];
        
        switch (c) {
            case '\\': 
                fprintf(output, "\\textbackslash{}");
                break;
            case '{':  
                fprintf(output, "\\{");
                break;
            case '}':  
                fprintf(output, "\\}");
                break;
            case '&':  
                fprintf(output, "\\&");
                break;
            case '%':  
                fprintf(output, "\\%");  
                break;
            case '$':  
                fprintf(output, "\\$");
                break;
            case '#':  
                fprintf(output, "\\#");
                break;
            case '_':  
                fprintf(output, "\\_");
                break;
            case '^':  
                fprintf(output, "\\^{}");
                break;
            case '~':  
                fprintf(output, "\\~{}");
                break;
            case '<':  
                fprintf(output, "\\textless{}");
                break;
            case '>':  
                fprintf(output, "\\textgreater{}");
                break;
            case '|':  
                fprintf(output, "\\textbar{}");
                break;
            default:
                // Caracteres normales, incluyendo tabs y espacios
                if (c == '\t') {
                    fprintf(output, "\\hspace*{0.5cm}"); // Tab como espacio
                } else {
                    fputc(c, output);
                }
                break;
        }
    }
}

void generar_portada(FILE* beamer) {
    fprintf(beamer, "\\begin{frame}\n");
    fprintf(beamer, "    \\centering\n");
    fprintf(beamer, "    \\vspace{0.5cm}\n");
    fprintf(beamer, "    {\\Huge\\bfseries Código Fuente}\\\\\n");
    fprintf(beamer, "    \\vspace{0.3cm}\n");
    fprintf(beamer, "    {\\Large Presentación del Archivo}\\\\\n");
    fprintf(beamer, "    \\vspace{0.5cm}\n");
    fprintf(beamer, "    {\\large Instituto Tecnológico de Costa Rica}\\\\\n");
    fprintf(beamer, "    \\vspace{1cm}\n");
    fprintf(beamer, "    {\\large\\bfseries Grupo de Trabajo:}\\\\\n");
    fprintf(beamer, "    {\\large Cristopher Céspedes}\\\\\n");
    fprintf(beamer, "    {\\large Christopher Alvarado}\\\\\n");
    fprintf(beamer, "    {\\large Jesús Solís Mora}\\\\\n");
    fprintf(beamer, "    \\vspace{1cm}\n");
    fprintf(beamer, "    {\\large Semestre: II 2025}\\\\\n");
    fprintf(beamer, "\\end{frame}\n\n");
}

void generar_codigo_completo(FILE* beamer, const char* filename) {
    FILE* archivo = fopen(filename, "r");
    if (!archivo) {
        fprintf(beamer, "\\begin{frame}[fragile]{Error}\n");
        fprintf(beamer, "\\begin{center}\n");
        fprintf(beamer, "{\\color{red}No se pudo abrir el archivo: %s}\n", filename);
        fprintf(beamer, "\\end{center}\n");
        fprintf(beamer, "\\end{frame}\n\n");
        return;
    }

    // Contar líneas para dividir en slides
    int total_lineas = 0;
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), archivo)) {
        total_lineas++;
    }
    rewind(archivo);

    int lineas_por_slide = 15;
    int total_slides = (total_lineas + lineas_por_slide - 1) / lineas_por_slide;

    for (int slide = 0; slide < total_slides; slide++) {
        int inicio = slide * lineas_por_slide + 1;
        int fin = (slide + 1) * lineas_por_slide;
        if (fin > total_lineas) fin = total_lineas;

        fprintf(beamer, "\\begin{frame}[fragile]{Código - Líneas %d a %d}\n", inicio, fin);
        fprintf(beamer, "\\scriptsize\n");
        fprintf(beamer, "\\begin{Verbatim}[commandchars=\\\\\\{\\}]\n");
        
        int linea_actual = 0;
        while (fgets(buffer, sizeof(buffer), archivo)) {
            linea_actual++;
            if (linea_actual >= inicio && linea_actual <= fin) {
                // Escapar caracteres especiales de LaTeX manteniendo formato original
                for (size_t i = 0; i < strlen(buffer); i++) {
                    unsigned char c = buffer[i];
                    
                    switch (c) {
                        case '\\': 
                            fprintf(beamer, "\\textbackslash{}");
                            break;
                        case '{':  
                            fprintf(beamer, "\\{");
                            break;
                        case '}':  
                            fprintf(beamer, "\\}");
                            break;
                        case '&':  
                            fprintf(beamer, "\\&");
                            break;
                        case '%':  
                            fprintf(beamer, "\\%");  
                            break;
                        case '$':  
                            fprintf(beamer, "\\$");
                            break;
                        case '#':  
                            fprintf(beamer, "\\#");
                            break;
                        case '_':  
                            fprintf(beamer, "\\_");
                            break;
                        case '^':  
                            fprintf(beamer, "\\^{}");
                            break;
                        case '~':  
                            fprintf(beamer, "\\~{}");
                            break;
                        case '<':  
                            fprintf(beamer, "\\textless{}");
                            break;
                        case '>':  
                            fprintf(beamer, "\\textgreater{}");
                            break;
                        case '|':  
                            fprintf(beamer, "\\textbar{}");
                            break;
                        default:
                            fputc(c, beamer);
                            break;
                    }
                }
            }
            if (linea_actual >= fin) break;
        }
        
        fprintf(beamer, "\\end{Verbatim}\n");
        fprintf(beamer, "\\end{frame}\n\n");
        
        if (linea_actual >= total_lineas) break;
    }
    
    fclose(archivo);
}

void generar_beamer_desde_archivo(const char* archivo_entrada) {
 
    FILE* beamer = fopen("PresentacionBeamer.tex", "w");
    if (!beamer) {
        fprintf(stderr, "❌ Error: No se puede crear archivo Beamer\n");
        return;
    }

    // Encabezado del documento LaTeX
    fprintf(beamer, "\\documentclass{beamer}\n");
    fprintf(beamer, "\\usepackage[utf8]{inputenc}\n");
    fprintf(beamer, "\\usepackage[spanish]{babel}\n");
    fprintf(beamer, "\\usepackage{graphicx}\n");
    fprintf(beamer, "\\usepackage{xcolor}\n");
    fprintf(beamer, "\\usepackage{fancyvrb}\n");
    fprintf(beamer, "\\usepackage{listings}\n");
    fprintf(beamer, "\\usetheme{Madrid}\n");
    fprintf(beamer, "\\usecolortheme{whale}\n");
    
    fprintf(beamer, "\\title{Presentación del Código Fuente}\n");
    fprintf(beamer, "\\subtitle{Archivo: %s}\n", archivo_entrada);
    fprintf(beamer, "\\author{Grupo de Trabajo}\n");
    fprintf(beamer, "\\date{II Semestre 2025}\n");
    
    fprintf(beamer, "\\begin{document}\n\n");
    
    generar_portada(beamer);
    generar_codigo_completo(beamer, archivo_entrada);
    
    // Frame final
    fprintf(beamer, "\\begin{frame}\n");
    fprintf(beamer, "    \\centering\n");
    fprintf(beamer, "    \\vspace{1cm}\n");
    fprintf(beamer, "    {\\Huge\\bfseries Fin}\\\\\n");
    fprintf(beamer, "    \\vspace{1cm}\n");
    fprintf(beamer, "    {\\Large Gracias por su atención}\n");
    fprintf(beamer, "\\end{frame}\n\n");
    
    fprintf(beamer, "\\end{document}\n");
    fclose(beamer);
    
    
    system("pdflatex -interaction=nonstopmode PresentacionBeamer.tex > /dev/null 2>&1");
    system("evince PresentacionBeamer.pdf");
    
    printf("✅ PDF generado exitosamente\n");
}
