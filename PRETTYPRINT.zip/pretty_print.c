#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define MAX_LINE_LENGTH 1024

// Configuración de estilos
typedef struct {
    int tamano_indentacion;
    int estilo_llaves;
    bool espacio_antes_parentesis;
    bool espacios_alrededor_operadores;
    bool lineas_vacias_entre_funciones;
    bool espacio_despues_comas;
    bool salto_linea_despues_punto_coma;
} ConfiguracionEstilo;


//   CONFIGURACIÓN DE ESTILOS


void configurar_estilo_gnu(ConfiguracionEstilo* estilo) {
    estilo->tamano_indentacion = 2;
    estilo->estilo_llaves = 1; // Llaves en línea siguiente
    estilo->espacio_antes_parentesis = true;
    estilo->espacios_alrededor_operadores = true;
    estilo->lineas_vacias_entre_funciones = true;
    estilo->espacio_despues_comas = true;
    estilo->salto_linea_despues_punto_coma = true;
}

void configurar_estilo_bsd(ConfiguracionEstilo* estilo) {
    estilo->tamano_indentacion = 4;
    estilo->estilo_llaves = 1; // Llaves en línea siguiente
    estilo->espacio_antes_parentesis = false;
    estilo->espacios_alrededor_operadores = true;
    estilo->lineas_vacias_entre_funciones = true;
    estilo->espacio_despues_comas = true;
    estilo->salto_linea_despues_punto_coma = true;
}

void configurar_estilo_personalizado(ConfiguracionEstilo* estilo) {
    estilo->tamano_indentacion = 4;
    estilo->estilo_llaves = 0; // Llaves en misma línea
    estilo->espacio_antes_parentesis = true;
    estilo->espacios_alrededor_operadores = false;
    estilo->lineas_vacias_entre_funciones = false;
    estilo->espacio_despues_comas = false;
    estilo->salto_linea_despues_punto_coma = true;
}

// FORMATO


void aplicar_indentaciosn(FILE* salida, int nivel, int tamano_indent) {
    for (int i = 0; i < nivel * tamano_indent; i++) {
        fputc(' ', salida);
    }
}

bool es_directiva_preprocesador(const char* linea) {
    const char* pos = linea;
    while (*pos && isspace(*pos)) pos++;
    return *pos == '#';
}

bool es_linea_comentario(const char* linea) {
    const char* pos = linea;
    while (*pos && isspace(*pos)) pos++;
    return (*pos == '/' && (*(pos + 1) == '/' || *(pos + 1) == '*'));
}

void contar_llaves(const char* linea, int* llaves_abiertas, int* llaves_cerradas) {
    *llaves_abiertas = 0;
    *llaves_cerradas = 0;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    
    for (const char* p = linea; *p; p++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (*p == '/' && *(p + 1) == '/') break;
            if (*p == '/' && *(p + 1) == '*') en_comentario = true;
            if (*p == '"' && (p == linea || *(p - 1) != '\\')) en_cadena = true;
            if (*p == '\'' && (p == linea || *(p - 1) != '\\')) en_caracter = true;
            if (*p == '{') (*llaves_abiertas)++;
            if (*p == '}') (*llaves_cerradas)++;
        } else if (en_comentario && *p == '*' && *(p + 1) == '/') {
            en_comentario = false;
            p++;
        } else if (en_cadena && *p == '"' && *(p - 1) != '\\') {
            en_cadena = false;
        } else if (en_caracter && *p == '\'' && *(p - 1) != '\\') {
            en_caracter = false;
        }
    }
}

// Función para verificar si estamos dentro de un for
bool es_parte_de_for(const char* linea, int pos_punto_coma) {
    // Buscar hacia atrás la palabra "for"
    int i = pos_punto_coma - 1;
    
    // Saltar espacios hacia atrás
    while (i >= 0 && isspace(linea[i])) {
        i--;
    }
    
    // Buscar "for" precedido por espacio o al inicio
    if (i >= 2 && 
        (linea[i] == 'r' || linea[i] == 'R') &&
        (linea[i-1] == 'o' || linea[i-1] == 'O') &&
        (linea[i-2] == 'f' || linea[i-2] == 'F')) {
        
        // Verificar que no sea parte de una palabra más larga
        if (i-3 < 0 || !isalnum(linea[i-3])) {
            return true;
        }
    }
    
    return false;
}

void aplicar_salto_linea_despues_punto_coma(char* linea, char** lineas_resultado, int* num_lineas) {
    char temporal[MAX_LINE_LENGTH * 2] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    bool en_for = false;
    
    *num_lineas = 0;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                // Comentario de línea - copiar hasta el final
                strcpy(destino, &linea[i]);
                destino += strlen(&linea[i]);
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            if (linea[i] == '\'') en_caracter = true;
            
            // Verificar si estamos en un for
            if (!en_for) {
                en_for = es_parte_de_for(linea, i);
            }
            
            // Procesar punto y coma
            if (linea[i] == ';') {
                *destino++ = ';';
                
                // Solo agregar salto de línea si NO estamos en un for
                if (!en_for) {
                    *destino = '\0';
                    if (strlen(temporal) > 0) {
                        strcpy(lineas_resultado[(*num_lineas)++], temporal);
                    }
                    // Resetear para la siguiente línea
                    destino = temporal;
                    *destino = '\0';
                }
                
                // Resetear la bandera de for después del ;
                en_for = false;
                continue;
            }
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        } else if (en_caracter && linea[i] == '\'' && (i == 0 || linea[i-1] != '\\')) {
            en_caracter = false;
        }
        
        *destino++ = linea[i];
    }
    
    // Agregar la última línea si queda contenido
    *destino = '\0';
    if (strlen(temporal) > 0) {
        strcpy(lineas_resultado[(*num_lineas)++], temporal);
    }
}

void aplicar_espacios_operadores(char* linea) {
    char temporal[MAX_LINE_LENGTH * 2] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                strcpy(destino, &linea[i]);
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            if (linea[i] == '\'') en_caracter = true;
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        } else if (en_caracter && linea[i] == '\'' && (i == 0 || linea[i-1] != '\\')) {
            en_caracter = false;
        }
        
        if (en_cadena || en_caracter || en_comentario) {
            *destino++ = linea[i];
            continue;
        }
        
        bool operador_procesado = false;
        
        // Operadores de 2 caracteres
        if (linea[i] == '=' && linea[i+1] == '=') {
            *destino++ = ' ';
            *destino++ = '=';
            *destino++ = '=';
            *destino++ = ' ';
            i++;
            operador_procesado = true;
        }
        else if (linea[i] == '!' && linea[i+1] == '=') {
            *destino++ = ' ';
            *destino++ = '!';
            *destino++ = '=';
            *destino++ = ' ';
            i++;
            operador_procesado = true;
        }
        else if (linea[i] == '<' && linea[i+1] == '=') {
            *destino++ = ' ';
            *destino++ = '<';
            *destino++ = '=';
            *destino++ = ' ';
            i++;
            operador_procesado = true;
        }
        else if (linea[i] == '>' && linea[i+1] == '=') {
            *destino++ = ' ';
            *destino++ = '>';
            *destino++ = '=';
            *destino++ = ' ';
            i++;
            operador_procesado = true;
        }
        else if (linea[i] == '+' && linea[i+1] == '=') {
            *destino++ = ' ';
            *destino++ = '+';
            *destino++ = '=';
            *destino++ = ' ';
            i++;
            operador_procesado = true;
        }
        else if (linea[i] == '-' && linea[i+1] == '=') {
            *destino++ = ' ';
            *destino++ = '-';
            *destino++ = '=';
            *destino++ = ' ';
            i++;
            operador_procesado = true;
        }
        else if (linea[i] == '*' && linea[i+1] == '=') {
            *destino++ = ' ';
            *destino++ = '*';
            *destino++ = '=';
            *destino++ = ' ';
            i++;
            operador_procesado = true;
        }
        else if (linea[i] == '/' && linea[i+1] == '=') {
            *destino++ = ' ';
            *destino++ = '/';
            *destino++ = '=';
            *destino++ = ' ';
            i++;
            operador_procesado = true;
        }
        else if (linea[i] == '%' && linea[i+1] == '=') {
            *destino++ = ' ';
            *destino++ = '%';
            *destino++ = '=';
            *destino++ = ' ';
            i++;
            operador_procesado = true;
        }
        // Operadores de 1 carácter
        else if (strchr("=+-*/%<>!&|", linea[i]) != NULL) {
            bool es_unario = false;
            if (i > 0) {
                char anterior = linea[i-1];
                if (strchr("(,=:[", anterior) != NULL || isspace(anterior)) {
                    es_unario = true;
                }
            }
            
            if (!es_unario) {
                *destino++ = ' ';
                *destino++ = linea[i];
                *destino++ = ' ';
                operador_procesado = true;
            } else {
                *destino++ = linea[i];
                operador_procesado = true;
            }
        }
        
        if (!operador_procesado) {
            *destino++ = linea[i];
        }
    }
    
    *destino = '\0';
    strcpy(linea, temporal);
}

void aplicar_espacio_despues_comas(char* linea) {
    char temporal[MAX_LINE_LENGTH * 2] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_caracter = false;
    bool en_comentario = false;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena && !en_caracter) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                strcpy(destino, &linea[i]);
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            if (linea[i] == '\'') en_caracter = true;
            
            if (linea[i] == ',') {
                *destino++ = ',';
                *destino++ = ' ';
                continue;
            }
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        } else if (en_caracter && linea[i] == '\'' && (i == 0 || linea[i-1] != '\\')) {
            en_caracter = false;
        }
        
        *destino++ = linea[i];
    }
    
    *destino = '\0';
    strcpy(linea, temporal);
}

void aplicar_espacio_antes_parentesis(char* linea) {
    char temporal[MAX_LINE_LENGTH * 2] = {0};
    char* destino = temporal;
    bool en_cadena = false;
    bool en_comentario = false;
    
    for (int i = 0; linea[i] != '\0'; i++) {
        if (!en_comentario && !en_cadena) {
            if (linea[i] == '/' && linea[i+1] == '/') {
                strcpy(destino, &linea[i]);
                break;
            }
            if (linea[i] == '/' && linea[i+1] == '*') en_comentario = true;
            if (linea[i] == '"') en_cadena = true;
            
            if (linea[i] == '(' && i > 0) {
                const char* palabras_reservadas[] = {
                    "if", "while", "for", "switch", "return", 
                    "sizeof", "case", "default"
                };
                const int num_palabras = sizeof(palabras_reservadas) / sizeof(palabras_reservadas[0]);
                
                int j = i - 1;
                while (j >= 0 && isspace(linea[j])) j--;
                
                if (j >= 0) {
                    int inicio = j;
                    while (inicio >= 0 && (isalnum(linea[inicio]) || linea[inicio] == '_')) {
                        inicio--;
                    }
                    inicio++;
                    
                    int longitud = j - inicio + 1;
                    char palabra[50] = {0};
                    strncpy(palabra, &linea[inicio], longitud);
                    
                    for (int p = 0; p < num_palabras; p++) {
                        if (strcmp(palabra, palabras_reservadas[p]) == 0) {
                            *destino++ = ' ';
                            break;
                        }
                    }
                }
            }
        } else if (en_comentario && linea[i] == '*' && linea[i+1] == '/') {
            en_comentario = false;
        } else if (en_cadena && linea[i] == '"' && (i == 0 || linea[i-1] != '\\')) {
            en_cadena = false;
        }
        
        *destino++ = linea[i];
    }
    
    *destino = '\0';
    strcpy(linea, temporal);
}

// Función para manejar el estilo de llaves
void aplicar_estilo_llaves(char* linea, int* nivel_indentacion, ConfiguracionEstilo config, FILE* salida) {
    char* pos_llave = strchr(linea, '{');
    if (pos_llave && config.estilo_llaves == 1) { // Llaves en línea siguiente
        // Separar la línea antes de la llave
        char parte_antes_llave[MAX_LINE_LENGTH] = {0};
        char* resto = NULL;
        
        int indice_llave = pos_llave - linea;
        strncpy(parte_antes_llave, linea, indice_llave);
        parte_antes_llave[indice_llave] = '\0';
        
        resto = &linea[indice_llave];
        
        // Si hay contenido antes de la llave, escribirlo
        if (strlen(parte_antes_llave) > 0) {
            char* p = parte_antes_llave;
            while (*p && isspace(*p)) p++; // Saltar espacios al inicio
            if (*p) { // Si hay contenido no-espacio
                aplicar_indentacion(salida, *nivel_indentacion, config.tamano_indentacion);
                fputs(parte_antes_llave, salida);
                fputc('\n', salida);
            }
        }
        
        // Escribir la llave en nueva línea con indentación
        aplicar_indentacion(salida, *nivel_indentacion, config.tamano_indentacion);
        fputs(resto, salida);
        fputc('\n', salida);
        
        // Actualizar nivel de indentación
        (*nivel_indentacion)++;
    } else {
        // Escribir la línea normalmente
        aplicar_indentacion(salida, *nivel_indentacion, config.tamano_indentacion);
        fputs(linea, salida);
        fputc('\n', salida);
        
        // Actualizar nivel de indentación si hay llaves
        int llaves_abiertas = 0, llaves_cerradas = 0;
        contar_llaves(linea, &llaves_abiertas, &llaves_cerradas);
        *nivel_indentacion += llaves_abiertas - llaves_cerradas;
        if (*nivel_indentacion < 0) *nivel_indentacion = 0;
    }
}


//   PRETTYPRINT PRINCIPAL


void formatear_codigo(const char* archivo_entrada, const char* archivo_salida, int estilo) {
    FILE* entrada = fopen(archivo_entrada, "r");
    FILE* salida = fopen(archivo_salida, "w");
    
    if (!entrada || !salida) {
        printf("❌ Error: No se pudo abrir los archivos\n");
        if (entrada) fclose(entrada);
        if (salida) fclose(salida);
        return;
    }

    // Configurar estilo según el parámetro
    ConfiguracionEstilo config;
    switch (estilo) {
        case 1: // GNU
            configurar_estilo_gnu(&config);
            break;
        case 2: // BSD
            configurar_estilo_bsd(&config);
            break;
        case 3: // Personalizado
            configurar_estilo_personalizado(&config);
            break;
        default:
            configurar_estilo_personalizado(&config);
            break;
    }

    char linea[MAX_LINE_LENGTH];
    int nivel_indentacion = 0;
    bool en_comentario_multilinea = false;
    bool linea_anterior_vacia = false;
    bool funcion_anterior_cerrada = false;
    
    while (fgets(linea, sizeof(linea), entrada)) {
        // Reemplazar tabs por espacios
        for (char* p = linea; *p; p++) {
            if (*p == '\t') {
                *p = ' ';
            }
        }
        
        linea[strcspn(linea, "\r\n")] = '\0';
        
        char* linea_limpia = linea;
        while (*linea_limpia && isspace(*linea_limpia)) linea_limpia++;
        
        bool linea_vacia = (strlen(linea_limpia) == 0);
        
        // Manejar comentarios multilínea
        if (en_comentario_multilinea) {
            if (strstr(linea_limpia, "*/")) {
                en_comentario_multilinea = false;
            }
            aplicar_indentacion(salida, nivel_indentacion, config.tamano_indentacion);
            fputs(linea_limpia, salida);
            fputc('\n', salida);
            linea_anterior_vacia = false;
            continue;
        }
        
        if (strstr(linea_limpia, "/*")) {
            en_comentario_multilinea = true;
            aplicar_indentacion(salida, nivel_indentacion, config.tamano_indentacion);
            fputs(linea_limpia, salida);
            fputc('\n', salida);
            linea_anterior_vacia = false;
            continue;
        }
        
        // Saltar líneas vacías consecutivas
        if (linea_vacia) {
            if (!linea_anterior_vacia && (funcion_anterior_cerrada || config.lineas_vacias_entre_funciones)) {
                fputc('\n', salida);
                linea_anterior_vacia = true;
            }
            continue;
        }
        linea_anterior_vacia = false;
        funcion_anterior_cerrada = false;
        
        // Directivas de preprocesador sin indentación
        if (es_directiva_preprocesador(linea_limpia)) {
            fputs(linea_limpia, salida);
            fputc('\n', salida);
            continue;
        }
        
        // Comentarios de línea
        if (es_linea_comentario(linea_limpia)) {
            aplicar_indentacion(salida, nivel_indentacion, config.tamano_indentacion);
            fputs(linea_limpia, salida);
            fputc('\n', salida);
            continue;
        }
        
        // Aplicar formato a la línea
        char linea_formateada[MAX_LINE_LENGTH];
        strcpy(linea_formateada, linea_limpia);
        
        if (config.espacios_alrededor_operadores) {
            aplicar_espacios_operadores(linea_formateada);
        }
        
        if (config.espacio_despues_comas) {
            aplicar_espacio_despues_comas(linea_formateada);
        }
        
        if (config.espacio_antes_parentesis) {
            aplicar_espacio_antes_parentesis(linea_formateada);
        }
        
        // Procesar salto de línea después de punto y coma (excepto en for)
        if (config.salto_linea_despues_punto_coma) {
            char* lineas_resultado[10]; // Máximo 10 líneas por división
            int num_lineas = 0;
            
            // Inicializar array de líneas
            for (int i = 0; i < 10; i++) {
                lineas_resultado[i] = malloc(MAX_LINE_LENGTH);
                lineas_resultado[i][0] = '\0';
            }
            
            aplicar_salto_linea_despues_punto_coma(linea_formateada, lineas_resultado, &num_lineas);
            
            // Procesar cada línea resultante
            for (int i = 0; i < num_lineas; i++) {
                if (strlen(lineas_resultado[i]) == 0) continue;
                
                char linea_actual[MAX_LINE_LENGTH];
                strcpy(linea_actual, lineas_resultado[i]);
                
                // Aplicar estilo de llaves si es necesario
                if (strchr(linea_actual, '{') != NULL && config.estilo_llaves == 1) {
                    aplicar_estilo_llaves(linea_actual, &nivel_indentacion, config, salida);
                } else {
                    // Contar llaves para indentación de esta línea
                    int llaves_abiertas = 0, llaves_cerradas = 0;
                    contar_llaves(linea_actual, &llaves_abiertas, &llaves_cerradas);
                    
                    // Ajustar indentación para llaves de cierre
                    int indentacion_actual = nivel_indentacion;
                    if (llaves_cerradas > 0) {
                        indentacion_actual = nivel_indentacion - llaves_cerradas;
                        if (indentacion_actual < 0) indentacion_actual = 0;
                    }
                    
                    // Aplicar indentación y escribir
                    aplicar_indentacion(salida, indentacion_actual, config.tamano_indentacion);
                    fputs(linea_actual, salida);
                    fputc('\n', salida);
                    
                    // Actualizar nivel de indentación
                    nivel_indentacion += llaves_abiertas - llaves_cerradas;
                    if (nivel_indentacion < 0) nivel_indentacion = 0;
                    
                    // Marcar si se cerró una función
                    if (llaves_cerradas > 0 && nivel_indentacion == 0) {
                        funcion_anterior_cerrada = true;
                    }
                }
            }
            
            // Liberar memoria
            for (int i = 0; i < 10; i++) {
                free(lineas_resultado[i]);
            }
            
            continue; 
        }
        
        if (strchr(linea_formateada, '{') != NULL && config.estilo_llaves == 1) {
            aplicar_estilo_llaves(linea_formateada, &nivel_indentacion, config, salida);
        } else {
            // Contar llaves para indentación
            int llaves_abiertas = 0, llaves_cerradas = 0;
            contar_llaves(linea_formateada, &llaves_abiertas, &llaves_cerradas);
            
            // Ajustar indentación para llaves de cierre
            int indentacion_actual = nivel_indentacion;
            if (llaves_cerradas > 0) {
                indentacion_actual = nivel_indentacion - llaves_cerradas;
                if (indentacion_actual < 0) indentacion_actual = 0;
            }
            
            // Aplicar indentación y escribir
            aplicar_indentacion(salida, indentacion_actual, config.tamano_indentacion);
            fputs(linea_formateada, salida);
            fputc('\n', salida);
            
            // Actualizar nivel de indentación
            nivel_indentacion += llaves_abiertas - llaves_cerradas;
            if (nivel_indentacion < 0) nivel_indentacion = 0;
            
            // Marcar si se cerró una función
            if (llaves_cerradas > 0 && nivel_indentacion == 0) {
                funcion_anterior_cerrada = true;
            }
        }
    }

    fclose(entrada);
    fclose(salida);
}