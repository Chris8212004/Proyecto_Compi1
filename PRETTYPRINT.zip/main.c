#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <stdbool.h>

extern int analizar_archivo(const char* nombre_archivo);
void formatear_codigo(const char* archivo_entrada, const char* archivo_salida, int estilo);
extern void generar_beamer_desde_archivo(const char* archivo_entrada);

// Configuración global
typedef struct {
    bool preproceso_activado;
    bool reemplazar_original;
    bool generar_beamer;
    int estilo;
    char* archivo_entrada;
} Configuracion;

void ejecutar_pretty_print(Configuracion config) {
    int resultado_sintaxis = analizar_archivo(config.archivo_entrada);

    if (resultado_sintaxis != 0) {
        printf("Código inválido - No se generó Pretty Print\n");
        return;
    }

    printf("Código válido - Generando Pretty Print\n");

    char archivo_salida[512];

    const char* punto = strrchr(config.archivo_entrada, '.');
    if (punto) {
        snprintf(archivo_salida, sizeof(archivo_salida), "%.*s.pretty%s",
                 (int)(punto - config.archivo_entrada),
                 config.archivo_entrada,
                 punto);
    } else {
        snprintf(archivo_salida, sizeof(archivo_salida), "%s.pretty",
                 config.archivo_entrada);
    }

    formatear_codigo(config.archivo_entrada, archivo_salida, config.estilo);

    if (!config.reemplazar_original) {
        printf("Pretty Print completado: %s\n", archivo_salida);
        return;
    }

    if (remove(config.archivo_entrada) != 0) {
        return;
    }

    if (rename(archivo_salida, config.archivo_entrada) != 0) {
        return;
    }

    printf("✔ Archivo original reemplazado: %s\n", config.archivo_entrada);
}


int main(int argc, char* argv[]) {
    if (argc == 1) {
        printf("Uso: %s <archivo.c>\n", argv[0]);
        return 0;
    }

    Configuracion config = {
        .preproceso_activado = false,
        .reemplazar_original = false,
        .generar_beamer = false,
        .estilo = 3,
        .archivo_entrada = argv[1]
    };
    
    FILE* test = fopen(config.archivo_entrada, "r");
    if (!test) {
        printf("Error: No se puede abrir el archivo '%s'\n", config.archivo_entrada);
        return 1;
    }
    fclose(test);
    
    printf("-h : Mostrar ayuda\n");

    char opcion[10];
    bool proceso_ejecutado = false;
    
    while (1) {
        if (fgets(opcion, sizeof(opcion), stdin) == NULL) {
            break;
        }
        opcion[strcspn(opcion, "\n")] = '\0';
        
        if (strcmp(opcion, "-p") == 0) {
            config.preproceso_activado = !config.preproceso_activado;
            printf("Preproceso %s\n", config.preproceso_activado ? "activado" : "desactivado");
        }
        else if (strcmp(opcion, "-r") == 0) {
            config.reemplazar_original = !config.reemplazar_original;
            printf("Reemplazar archivo original %s\n", config.reemplazar_original ? "activado" : "desactivado");
        }
        else if (strcmp(opcion, "-g") == 0) {
            config.estilo = 1; // GNU
            ejecutar_pretty_print(config);
            proceso_ejecutado = true;
            printf("Estilo GNU seleccionado\n");

        }
        else if (strcmp(opcion, "-b") == 0) {
            config.estilo = 2; // BSD
            ejecutar_pretty_print(config);
            proceso_ejecutado = true;
            printf("Estilo BSD seleccionado\n");
        }

        else if (strcmp(opcion, "-B") == 0) {
            printf("Generando Beamer \n");
            generar_beamer_desde_archivo(config.archivo_entrada);
            
        }
        else if (strcmp(opcion, "-h") == 0) {
            printf("\nAYUDA:\n");
            printf("-p : Activar/desactivar preproceso\n");
            printf("-r : Activar/desactivar reemplazo de archivo original\n");
            printf("-g : Seleccionar estilo GNU\n");
            printf("-b : Seleccionar estilo BSD\n");
            printf("-B : Activar/desactivar generación de Beamer\n");
            printf("-e : Ejecutar Pretty Print con configuración actual\n");
            printf("-h : Mostrar esta ayuda\n");
            printf("-q : Salir del programa\n");
        }
        else if (strcmp(opcion, "-q") == 0) {
            break;
        }
        else if (strlen(opcion) > 0) {
            printf("Opción no válida. Use -h para ayuda.\n");
        }
    }
    
    if (!proceso_ejecutado) {
        printf("No se ejecutó ningún proceso de Pretty Print\n");
    }
    
    return 0;
}